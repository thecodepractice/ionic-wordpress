/**
 * Generated bundle index. Do not edit.
 */
export * from './index';
export { NgswCommChannel as ɵangular_packages_service_worker_service_worker_a } from './src/low_level';
export { RegistrationOptions as ɵangular_packages_service_worker_service_worker_b, SCRIPT as ɵangular_packages_service_worker_service_worker_c, ngswAppInitializer as ɵangular_packages_service_worker_service_worker_d, ngswCommChannelFactory as ɵangular_packages_service_worker_service_worker_e } from './src/module';
