/// <amd-module name="@angular/service-worker/config/index.ngsummary" />
export {};
