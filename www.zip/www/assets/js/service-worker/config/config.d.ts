/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="@angular/service-worker/config/config" />
export * from './index';
