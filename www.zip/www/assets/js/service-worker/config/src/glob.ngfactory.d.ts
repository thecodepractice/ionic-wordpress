/// <amd-module name="@angular/service-worker/config/src/glob.ngfactory" />
export {};
