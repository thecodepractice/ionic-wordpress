/// <amd-module name="@angular/service-worker/config/src/generator.ngsummary" />
export {};
