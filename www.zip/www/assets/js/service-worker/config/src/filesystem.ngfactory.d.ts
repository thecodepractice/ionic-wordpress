/// <amd-module name="@angular/service-worker/config/src/filesystem.ngfactory" />
export {};
