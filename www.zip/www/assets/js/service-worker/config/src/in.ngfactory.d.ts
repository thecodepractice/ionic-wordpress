/// <amd-module name="@angular/service-worker/config/src/in.ngfactory" />
export {};
