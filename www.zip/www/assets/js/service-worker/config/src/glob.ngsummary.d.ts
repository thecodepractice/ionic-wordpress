/// <amd-module name="@angular/service-worker/config/src/glob.ngsummary" />
export {};
