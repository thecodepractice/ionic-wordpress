/// <amd-module name="@angular/service-worker/config/index.ngfactory" />
export {};
