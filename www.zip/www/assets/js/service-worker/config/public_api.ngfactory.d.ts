/// <amd-module name="@angular/service-worker/config/public_api.ngfactory" />
export {};
