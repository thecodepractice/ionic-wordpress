/// <amd-module name="@angular/service-worker/config/public_api.ngsummary" />
export {};
