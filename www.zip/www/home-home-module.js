(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["home-home-module"],{

/***/ "./node_modules/jw-angular-pagination/lib/jw-pagination.component.js":
/*!***************************************************************************!*\
  !*** ./node_modules/jw-angular-pagination/lib/jw-pagination.component.js ***!
  \***************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var paginate = __webpack_require__(/*! jw-paginate */ "./node_modules/jw-paginate/lib/jw-paginate.js");
var JwPaginationComponent = /** @class */ (function () {
    function JwPaginationComponent() {
        this.changePage = new core_1.EventEmitter(true);
        this.initialPage = 1;
        this.pageSize = 10;
        this.maxPages = 10;
        this.pager = {};
    }
    JwPaginationComponent.prototype.ngOnInit = function () {
        // set page if items array isn't empty
        if (this.items && this.items.length) {
            this.setPage(this.initialPage);
        }
    };
    JwPaginationComponent.prototype.ngOnChanges = function (changes) {
        // reset page if items array has changed
        if (changes.items.currentValue !== changes.items.previousValue) {
            this.setPage(this.initialPage);
        }
    };
    JwPaginationComponent.prototype.setPage = function (page) {
        // get new pager object for specified page
        this.pager = paginate(this.items.length, page, this.pageSize, this.maxPages);
        // get new page of items from items array
        var pageOfItems = this.items.slice(this.pager.startIndex, this.pager.endIndex + 1);
        // call change page function in parent component
        this.changePage.emit(pageOfItems);
    };
    JwPaginationComponent.decorators = [
        { type: core_1.Component, args: [{
                    moduleId: module.i,
                    selector: 'jw-pagination',
                    template: "<ul *ngIf=\"pager.pages && pager.pages.length\" class=\"pagination\">\n  <li [ngClass]=\"{disabled:pager.currentPage === 1}\" class=\"page-item first-item\">\n      <a (click)=\"setPage(1)\" class=\"page-link\">First</a>\n  </li>\n  <li [ngClass]=\"{disabled:pager.currentPage === 1}\" class=\"page-item previous-item\">\n      <a (click)=\"setPage(pager.currentPage - 1)\" class=\"page-link\">Previous</a>\n  </li>\n  <li *ngFor=\"let page of pager.pages\" [ngClass]=\"{active:pager.currentPage === page}\" class=\"page-item number-item\">\n      <a (click)=\"setPage(page)\" class=\"page-link\">{{page}}</a>\n  </li>\n  <li [ngClass]=\"{disabled:pager.currentPage === pager.totalPages}\" class=\"page-item next-item\">\n      <a (click)=\"setPage(pager.currentPage + 1)\" class=\"page-link\">Next</a>\n  </li>\n  <li [ngClass]=\"{disabled:pager.currentPage === pager.totalPages}\" class=\"page-item last-item\">\n      <a (click)=\"setPage(pager.totalPages)\" class=\"page-link\">Last</a>\n  </li>\n</ul>"
                },] },
    ];
    /** @nocollapse */
    JwPaginationComponent.propDecorators = {
        "items": [{ type: core_1.Input },],
        "changePage": [{ type: core_1.Output },],
        "initialPage": [{ type: core_1.Input },],
        "pageSize": [{ type: core_1.Input },],
        "maxPages": [{ type: core_1.Input },],
    };
    return JwPaginationComponent;
}());
exports.JwPaginationComponent = JwPaginationComponent;


/***/ }),

/***/ "./node_modules/jw-paginate/lib/jw-paginate.js":
/*!*****************************************************!*\
  !*** ./node_modules/jw-paginate/lib/jw-paginate.js ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

function paginate(totalItems, currentPage, pageSize, maxPages) {
    if (currentPage === void 0) { currentPage = 1; }
    if (pageSize === void 0) { pageSize = 10; }
    if (maxPages === void 0) { maxPages = 10; }
    // calculate total pages
    var totalPages = Math.ceil(totalItems / pageSize);
    // ensure current page isn't out of range
    if (currentPage < 1) {
        currentPage = 1;
    }
    else if (currentPage > totalPages) {
        currentPage = totalPages;
    }
    var startPage, endPage;
    if (totalPages <= maxPages) {
        // total pages less than max so show all pages
        startPage = 1;
        endPage = totalPages;
    }
    else {
        // total pages more than max so calculate start and end pages
        var maxPagesBeforeCurrentPage = Math.floor(maxPages / 2);
        var maxPagesAfterCurrentPage = Math.ceil(maxPages / 2) - 1;
        if (currentPage <= maxPagesBeforeCurrentPage) {
            // current page near the start
            startPage = 1;
            endPage = maxPages;
        }
        else if (currentPage + maxPagesAfterCurrentPage >= totalPages) {
            // current page near the end
            startPage = totalPages - maxPages + 1;
            endPage = totalPages;
        }
        else {
            // current page somewhere in the middle
            startPage = currentPage - maxPagesBeforeCurrentPage;
            endPage = currentPage + maxPagesAfterCurrentPage;
        }
    }
    // calculate start and end item indexes
    var startIndex = (currentPage - 1) * pageSize;
    var endIndex = Math.min(startIndex + pageSize - 1, totalItems - 1);
    // create an array of pages to ng-repeat in the pager control
    var pages = Array.from(Array((endPage + 1) - startPage).keys()).map(function (i) { return startPage + i; });
    // return object with all pager properties required by the view
    return {
        totalItems: totalItems,
        currentPage: currentPage,
        pageSize: pageSize,
        totalPages: totalPages,
        startPage: startPage,
        endPage: endPage,
        startIndex: startIndex,
        endIndex: endIndex,
        pages: pages
    };
}
module.exports = paginate;


/***/ }),

/***/ "./src/app/home/home.module.ts":
/*!*************************************!*\
  !*** ./src/app/home/home.module.ts ***!
  \*************************************/
/*! exports provided: HomePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomePageModule", function() { return HomePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var jw_angular_pagination__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! jw-angular-pagination */ "./node_modules/jw-angular-pagination/lib/jw-pagination.component.js");
/* harmony import */ var jw_angular_pagination__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(jw_angular_pagination__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _home_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./home.page */ "./src/app/home/home.page.ts");








var HomePageModule = /** @class */ (function () {
    function HomePageModule() {
    }
    HomePageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_5__["RouterModule"].forChild([
                    {
                        path: '',
                        component: _home_page__WEBPACK_IMPORTED_MODULE_7__["HomePage"]
                    }
                ])
            ],
            declarations: [_home_page__WEBPACK_IMPORTED_MODULE_7__["HomePage"], jw_angular_pagination__WEBPACK_IMPORTED_MODULE_6__["JwPaginationComponent"]]
        })
    ], HomePageModule);
    return HomePageModule;
}());



/***/ }),

/***/ "./src/app/home/home.page.html":
/*!*************************************!*\
  !*** ./src/app/home/home.page.html ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-content padding class=\"main\">\r\n<ion-header>\r\n  <!---ion-toolbar>\r\n    <ion-buttons slot=\"start\">\r\n      <ion-menu-button></ion-menu-button>\r\n    </ion-buttons>\r\n    <ion-title>\r\n      Home\r\n    </ion-title>\r\n  </ion-toolbar--->\r\n  <header>\r\n\r\n\t\t<div class=\"top_bar\">\r\n\t\t\t<div class=\"container\">\r\n\t\t\t\t<ul>\t\t\t\t\t\r\n\t\t\t\t\t<li>\r\n\t\t\t\t\t\t<a href=\"https://www.facebook.com/\" target=\"_blank\"><i class=\"fab fa-facebook-f\"></i></a>\r\n\t\t\t\t\t\t<a href=\"https://twitter.com/\" target=\"_blank\"><i class=\"fab fa-twitter\"></i></a>\r\n\t\t\t\t\t\t<a href=\"https://www.linkedin.com/\" target=\"_blank\"><i class=\"fab fa-linkedin-in\"></i></a>\r\n\t\t\t\t\t\t\r\n\t\t\t\t\t</li>\r\n\t\t\t\t</ul>\r\n\t\t\t</div>\r\n\t\t\t</div>\r\n\t\t<div class=\"header-section\">\t\r\n\t\t\t<div class=\"container\">\r\n\t\t\t\t<div class=\"row\">\r\n\t\t\t\t\t<div class=\"logo\">\r\n\t\t\t\t\t\t<a href=\"/home\"><img src=\"../../assets/images/logo.png\"></a>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t\t<div class=\"lower_bar\">\r\n\t\t\t\t\t\t<nav class=\"navbar navbar-expand-lg navbar-light bg-light\">\r\n\t\t\t\t\t\t<button class=\"navbar-toggler\" type=\"button\" data-toggle=\"collapse\" data-target=\"#navbarSupportedContent\" aria-controls=\"navbarSupportedContent\" aria-expanded=\"false\" aria-label=\"Toggle navigation\"><span class=\"navbar-toggler-icon\"></span></button><div class=\"collapse navbar-collapse\" id=\"navbarSupportedContent\">\r\n\t\t\t\t\t\t<ul class=\"navbar-nav mr-auto\">\r\n\t\t\t\t\t\t\t<li class=\"nav-item active\"><a class=\"nav-link\" href=\"/home\">Home</a></li>\r\n\t\t\t\t\t\t\t<li class=\"nav-item active\"><a class=\"nav-link\" href=\"/about\">About Us</a></li>\r\n\t\t\t\t\t\t\t<li class=\"nav-item\"><a class=\"nav-link\" href=\"/contact\">Contact Us</a></li>\r\n\t\t\t\t\t\t</ul></div></nav>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t</div>\r\n\t\t\t</div>\r\n\t\t</div>\r\n\t\t<div class=\"banner-img\">\r\n\t\t<img src=\"../../assets/images/banner1.jpg\">\r\n\t\t</div>\r\n\t</header>\r\n\t\r\n</ion-header>\r\n\r\n<div class=\"ion-padding custom-skeleton post-skeleton\" *ngIf=\"skeletion\">\r\n<div class=\"container\" >\r\n  <ion-grid>\r\n  <ion-row>\r\n    <ion-col size-xs=\"12\" size-md=\"6\" size-lg=\"3\">\r\n     <ion-skeleton-text animated style=\"height: 200px\"></ion-skeleton-text>\r\n\t  <ion-skeleton-text animated style=\"height: 40px\"></ion-skeleton-text>\r\n\t   <ion-skeleton-text animated style=\"height: 20px;width:80px;\"></ion-skeleton-text>\r\n\t    <ion-skeleton-text animated style=\"height: 80px\"></ion-skeleton-text>\r\n\t\t <ion-skeleton-text animated style=\"height: 40px; width:100px;\"></ion-skeleton-text>\r\n    </ion-col>\r\n    <ion-col size-xs=\"12\" size-md=\"6\" size-lg=\"3\">\r\n     <ion-skeleton-text animated style=\"height: 200px\"></ion-skeleton-text>\r\n\t  <ion-skeleton-text animated style=\"height: 40px\"></ion-skeleton-text>\r\n\t   <ion-skeleton-text animated style=\"height: 20px;width:80px;\"></ion-skeleton-text>\r\n\t    <ion-skeleton-text animated style=\"height: 80px\"></ion-skeleton-text>\r\n\t\t <ion-skeleton-text animated style=\"height: 40px; width:100px;\"></ion-skeleton-text>\r\n    </ion-col>\r\n  <ion-col size-xs=\"12\" size-md=\"6\" size-lg=\"3\">\r\n     <ion-skeleton-text animated style=\"height: 200px\"></ion-skeleton-text>\r\n\t  <ion-skeleton-text animated style=\"height: 40px\"></ion-skeleton-text>\r\n\t   <ion-skeleton-text animated style=\"height: 20px;width:80px;\"></ion-skeleton-text>\r\n\t    <ion-skeleton-text animated style=\"height: 80px\"></ion-skeleton-text>\r\n\t\t <ion-skeleton-text animated style=\"height: 40px; width:100px;\"></ion-skeleton-text>\r\n    </ion-col>\r\n    <ion-col size-xs=\"12\" size-md=\"6\" size-lg=\"3\">\r\n     <ion-skeleton-text animated style=\"height: 200px\"></ion-skeleton-text>\r\n\t  <ion-skeleton-text animated style=\"height: 40px\"></ion-skeleton-text>\r\n\t   <ion-skeleton-text animated style=\"height: 20px;width:80px;\"></ion-skeleton-text>\r\n\t    <ion-skeleton-text animated style=\"height: 80px\"></ion-skeleton-text>\r\n\t\t <ion-skeleton-text animated style=\"height: 40px; width:100px;\"></ion-skeleton-text>\r\n    </ion-col>\r\n  </ion-row>\r\n </ion-grid>\r\n\r\n</div>\r\n\t\r\n  </div>\r\n\r\n\r\n  <ion-list *ngIf=\"section_web\">\r\n\t<div class=\"container\">\r\n\t\r\n   <ion-col *ngFor=\"let item of pageOfItems\" size-md=\"8\" size-lg=\"4\" >\r\n      <div class=\"post_block\">\t\r\n\t  <a href=\"/{{item.slug}}\">\r\n\t\t\r\n\t\t<div class=\"blog-box\">\r\n\t\t<ion-card-title [innerHTML]=\"item.title.rendered\"></ion-card-title>  \r\n\t\t<ion-card-subtitle>{{ item.date | date:dateFormat }}</ion-card-subtitle>\r\n\t\t<div [innerHTML]=\"item.cat_names\" class=\"tags\"></div>\r\n\t\t<div [innerHTML]=\"strip_html_tags(item.content.rendered | slice:0:200)\" class=\"discription\"></div>\r\n\t\t</div>\r\n\t\t<ion-button href=\"/{{item.slug}}\" routerDirection=\"root\" color=\"primary\" size=\"small\">Read more...</ion-button>\t\r\n\t</a>\r\n\t</div>\r\n    </ion-col>\r\n\t<div class=\"loadmore-page\">\r\n\t<div class=\"loadmore\">\r\n\t <jw-pagination [items]=\"items\" [pageSize]=\"6\" (changePage)=\"onChangePage($event)\"></jw-pagination>\r\n\t</div>\r\n\t</div>\r\n\t</div>\r\n  </ion-list>\r\n  \r\n  <div class=\"awebrform\">\r\n  \r\n  \r\n  <div id=\"af-header-343701222\" class=\"af-header\">\r\n\t  <div class=\"bodyText\">\r\n\t\t\t  <span style=\"font-size: 36px; font-family: helvetica;\">\r\n\t\t\t  <strong>\r\n\t\t\t  <span style=\"color: #0087b7\">Have any questions?</span></strong>\r\n\t\t\t  </span>\t\t \r\n\t  </div>\r\n  </div>\r\n  <div class=\"af-element form-img\" style=\"text-align: center; width:100%; float:none;\">\r\n\t\t<button style=\"margin:20px 0;margin:20px 0;background-color: #0087b7;border: none;\" type=\"button\" class=\"btn btn-primary\" data-toggle=\"modal\" data-target=\"#myModal1\">Click Here</button>\r\n  </div>\r\n  \r\n  </div>\r\n\r\n  <div class=\"footer-section\">\r\n\t<div class=\"container\">\r\n\t\t<div class=\"row\">\r\n\t\t\t<div class=\"col-sm-4 footer1\"><figure class=\"image\"><img src=\"../../assets/images/logo.png\" alt=\"The Code Practice\"></figure>\r\n\t\t\t<p></p>\r\n\t\t\t</div>\r\n\t\t\t<div class=\"col-sm-3 footer1\">\r\n\t\t\t<h2>About Me</h2>\r\n\t\t\t<p><a href=\"/about\">I’m a writer, blogger and seriously passionate about development and looking the best while doing it!</a></p>\r\n\t\t\t</div>\r\n\t\t\t<div class=\"col-sm-3 footer1\">\r\n\t\t\t<h2>Menus</h2>\r\n\t\t\t<ul><li><a class=\"navbar-item\" href=\"/home\">Blog</a></li><li><a class=\"navbar-item\" href=\"/contact\">Contact me</a></li></ul>\r\n\t\t\t</div>\r\n\t\t\t<div class=\"col-sm-2 footer1\"><button type=\"button\" class=\"btn btn-primary\" data-toggle=\"modal\" data-target=\"#myModal\">Message Me</button></div>\r\n\t\t</div>\r\n\t</div>\r\n\t\t<div class=\"bottom-footer\">\r\n\t\t\t<div class=\"container\">\r\n\t\t\t\t<div class=\"row\">\r\n\t\t\t\t\t<div class=\"col-sm-8 left-menu\">\r\n\t\t\t\t\t<ul><li>The Code Practice © 2020</li><li><a class=\"navbar-item\" href=\"/privacy-policy\">Privacy Policy</a></li><li><a class=\"navbar-item\" href=\"/terms-and-conditions\">Terms and Conditions</a></li></ul>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t<div class=\"col-sm-4 right-menu\">\r\n\t\t\t\t\t<ul>\r\n\t\t\t\t\t<li><a href=\"https://www.facebook.com/\" target=\"_blank\"><i class=\"fab fa-facebook-f\"></i></a></li>\r\n\t\t\t\t\t<li><a href=\"https://twitter.com/\" target=\"_blank\"><i class=\"fab fa-twitter\"></i></a></li>\r\n\t\t\t\t\t<li><a href=\"https://www.linkedin.com/\" target=\"_blank\"><i class=\"fab fa-linkedin-in\"></i></a></li>\r\n\t\t\t\t\t<li><a href=\"#\"><i class=\"fas fa-wifi\"></i></a></li>\r\n\t\t\t\t\t</ul>\r\n\t\t\t\t</div>\r\n\t\t\t\t</div>\r\n\t\t\t</div>\r\n\t\t</div>\r\n</div>\r\n</ion-content>\r\n"

/***/ }),

/***/ "./src/app/home/home.page.scss":
/*!*************************************!*\
  !*** ./src/app/home/home.page.scss ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "body {\n  font-family: 'Open Sans', sans-serif; }\n\nul {\n  padding: 0; }\n\nion-content .inner-scroll {\n  padding-left: 0px !important;\n  padding-right: 0px !important;\n  -webkit-padding-start: unset !important;\n  padding-inline-start: unset !important;\n  -webkit-padding-end: unset !important;\n  padding-inline-end: unset !important; }\n\n.welcome-card ion-img {\n  max-height: 35vh;\n  overflow: hidden; }\n\n.banner-img img {\n  width: 100%; }\n\n.menu-type-overlay.menu-enabled.menu-side-start.hydrated.split-pane-side.menu-pane-visible {\n  display: none; }\n\napp-home .ion-page {\n  position: relative;\n  display: unset; }\n\n.top_bar {\n  text-align: right;\n  background-color: #036; }\n\n.top_bar ul {\n    margin: 0;\n    padding: 2px 0; }\n\n.top_bar ul li {\n    display: inline-block; }\n\n.top_bar ul li a {\n    color: #fff;\n    padding: 0 7px; }\n\n.header-section {\n  width: 100%;\n  padding: 10px 0; }\n\n.logo {\n  width: 50%; }\n\n.logo img {\n    width: 320px; }\n\n.lower_bar {\n  width: 50%; }\n\n.lower_bar nav.navbar.navbar-expand-lg.navbar-light.bg-light {\n    padding: 32px 0;\n    background-color: transparent !important; }\n\n.lower_bar nav.navbar ul {\n    text-align: right;\n    display: inline-block;\n    width: 100%; }\n\n.lower_bar nav.navbar ul li {\n      padding: 0 10px;\n      display: inline-block; }\n\n.lower_bar nav.navbar ul a {\n      text-transform: uppercase;\n      font-size: 14px;\n      color: #002231 !important;\n      font-weight: 700;\n      font-family: 'Open Sans', sans-serif;\n      letter-spacing: .1em;\n      transition: all .3s linear 0ms;\n      position: relative; }\n\n.lower_bar nav.navbar ul li.nav-item.active a::after,\n    .lower_bar nav.navbar ul a:hover:after {\n      content: \"\";\n      position: absolute;\n      background-color: #036;\n      width: 20px;\n      height: 6px;\n      bottom: 0;\n      left: 0;\n      right: 0;\n      margin: auto; }\n\n.footer-section {\n  width: 100%;\n  background-color: #f1f1f1;\n  padding: 60px 0 0;\n  float: left;\n  font-family: 'Open Sans', sans-serif; }\n\n.footer-section .footer1 figure.image {\n    margin: 0; }\n\n.footer-section .footer1 img {\n    width: 245px !important;\n    margin-bottom: 10px; }\n\n.footer-section .footer1 p {\n    padding: 0 55px 0 0;\n    font-size: 14px;\n    color: #504f4f;\n    line-height: 26px; }\n\n.footer-section .footer1 ul li {\n    padding: 0;\n    margin: 0;\n    display: block; }\n\n.footer-section .footer1 a.navbar-item {\n    cursor: pointer;\n    font-size: 14px;\n    text-decoration: none;\n    color: #504f4f;\n    background: transparent !important;\n    padding: 0;\n    margin-bottom: 10px; }\n\n.footer-section .footer1 a.navbar-item:hover {\n    color: #6a8c30; }\n\n.footer-section .footer1 h2 {\n    font-weight: 700;\n    font-size: 22px;\n    margin: 0 0 60px 0; }\n\n.footer-section .footer1 button {\n    background: transparent;\n    border: 2px solid #036;\n    color: #036;\n    font-size: 14px;\n    line-height: 1;\n    letter-spacing: .02em;\n    margin: 0;\n    padding: 10px 38px;\n    position: relative;\n    text-transform: uppercase;\n    font-weight: 700;\n    transition: all .3s linear 0ms; }\n\n.footer-section .footer1 button:hover {\n    background: #036;\n    color: #fff; }\n\n.footer-section .bottom-footer {\n    width: 100%;\n    background-color: #dde1da;\n    padding: 20px 0;\n    margin-top: 65px; }\n\n.footer-section .bottom-footer ul {\n      margin: 0;\n      padding: 0; }\n\n.footer-section .bottom-footer ul li {\n      display: inline-block;\n      padding: 0 12px  0 0px;\n      margin: 0;\n      color: #000;\n      font-size: 14px; }\n\n.footer-section .bottom-footer ul li a {\n      color: #036; }\n\n.footer-section .bottom-footer col-sm-6.right-menu {\n      text-align: right; }\n\n.footer-section .bottom-footer a.css-1dnwvu3 {\n      color: #000;\n      text-transform: uppercase;\n      font-weight: 700;\n      font-size: 14px; }\n\n.footer-section .bottom-footer .navbar-start nav.navbar.navbar-expand-lg.navbar-light.bg-light {\n      background: transparent !important;\n      padding: 0; }\n\n.footer1 a {\n  color: #504f4f;\n  text-decoration: none !important; }\n\n.footer1 a:hover {\n  color: #036; }\n\nion-list.md.list-md.hydrated {\n  margin: 35px 0;\n  width: 100%;\n  float: left;\n  clear: both; }\n\nion-list.md.list-md.hydrated ion-card-title.md.hydrated {\n    font-size: 16px;\n    color: #001822;\n    text-transform: uppercase;\n    font-weight: 700;\n    padding: 10px 0 15px 0;\n    font-family: 'Open Sans', sans-serif;\n    min-height: 0px; }\n\nion-list.md.list-md.hydrated .post_block {\n    border: 1px solid #ddd;\n    padding: 10px; }\n\nion-list.md.list-md.hydrated .post_block img {\n    height: 190px;\n    -o-object-fit: cover;\n       object-fit: cover;\n    width: 100%; }\n\nion-list.md.list-md.hydrated .discription {\n    font-size: 14px;\n    color: #797777;\n    line-height: 24px;\n    font-family: 'Open Sans', sans-serif;\n    min-height: 145px; }\n\nion-list.md.list-md.hydrated ion-button.ion-color.ion-color-primary {\n    --ion-color-base: #036 !important; }\n\nion-list.md.list-md.hydrated ion-card-subtitle.md.hydrated {\n    color: #036; }\n\nion-col.md.hydrated {\n  padding: 10px 10px;\n  float: left;\n  vertical-align: top; }\n\n.ion-padding.custom-skeleton.post-skeleton {\n  margin: 35px 0; }\n\n.ion-padding, [padding] {\n  --padding-start: var(--ion-padding, 0px);\n  --padding-end: var(--ion-padding, 0px);\n  --padding-top: var(--ion-padding, 0px);\n  --padding-bottom: var(--ion-padding, 0px);\n  padding-left: var(--ion-padding, 0px);\n  padding-right: var(--ion-padding, 0px);\n  padding-top: var(--ion-padding, 0px);\n  padding-bottom: var(--ion-padding, 0px); }\n\nbutton:focus {\n  outline: none; }\n\n.loadmore-page {\n  width: 100%;\n  text-align: center;\n  clear: both; }\n\n.loadmore {\n  display: inline-block;\n  margin-top: 30px; }\n\n.right-menu {\n  text-align: right; }\n\n.blog-box {\n  height: 260px; }\n\n.tags {\n  min-height: 0px;\n  margin-bottom: 10px; }\n\n.post_block a {\n  text-decoration: none;\n  color: unset; }\n\n/*form css*/\n\ndiv#af-form-343701222 img {\n  margin: auto;\n  text-align: center;\n  width: 100%; }\n\ndiv#af-header-343701222 {\n  text-align: center;\n  width: 100%;\n  float: left; }\n\n.af-element.form-img {\n  width: 50%;\n  float: left; }\n\ndiv#af-body-343701222 {\n  width: 50%;\n  float: left;\n  padding: 0 0 0 30px; }\n\ndiv#af-body-343701222 .af-element {\n  width: 100%; }\n\n.awebrform {\n  background-image: url('repair_section_back.jpg');\n  background-size: cover;\n  background-repeat: no-repeat; }\n\n.buttonContainer input.submit {\n  margin: 15px 0; }\n\ndiv#af-body-343701222 {\n  padding: 34px 0 17px 30px; }\n\n/*media query start from here*/\n\n@media (max-width: 1199px) {\n  .lower_bar nav.navbar ul a {\n    text-transform: uppercase;\n    font-size: 12px !important; }\n  ion-list.md.list-md.hydrated ion-card-title.md.hydrated {\n    /*  min-height: 60px; */\n    font-size: 14px; }\n  ion-list.md.list-md.hydrated .discription {\n    min-height: 170px; }\n  .lower_bar nav.navbar ul li {\n    padding: 0 6px; } }\n\n@media (min-width: 991px) and (max-width: 1200px) {\n  .blog-box {\n    height: 310px; } }\n\n@media (max-width: 991px) {\n  .lower_bar nav.navbar.navbar-expand-lg.navbar-light.bg-light {\n    float: right;\n    width: 100%;\n    position: absolute;\n    left: 0;\n    right: 0; }\n  .lower_bar .navbar-toggler {\n    width: 100%;\n    border: none;\n    text-align: right; }\n  .lower_bar .navbar-collapse {\n    position: absolute;\n    top: 101px;\n    background-color: #036;\n    z-index: 999;\n    width: 100%; }\n  .lower_bar nav.navbar ul li {\n    display: block; }\n  .lower_bar nav.navbar ul a {\n    color: #fff !important; }\n  .lower_bar nav.navbar ul {\n    padding: 15px 0; }\n  .lower_bar nav.navbar ul a:hover::after {\n    content: none; }\n  .footer-section .footer1 button {\n    padding: 10px 24px; }\n  .footer-section .footer1 p {\n    padding: 0 15px 0 0; }\n  .blog-box {\n    height: 300px; }\n  .lower_bar nav.navbar ul li.nav-item.active a::after, .lower_bar nav.navbar ul a:hover:after {\n    left: auto;\n    right: 0; } }\n\n@media (max-width: 767px) {\n  .lower_bar nav.navbar.navbar-expand-lg.navbar-light.bg-light {\n    padding: 16px 0; }\n  .logo {\n    padding: 0 10px; }\n  .logo img {\n    width: 200px; }\n  .lower_bar .navbar-collapse {\n    top: 70px; }\n  ion-list.md.list-md.hydrated ion-card-title.md.hydrated {\n    /*min-height: 100%;*/\n    margin-bottom: 10px; }\n  ion-list.md.list-md.hydrated .discription {\n    min-height: 100%; }\n  .right-menu {\n    text-align: center; }\n  .loadmore-page {\n    width: 100%;\n    max-width: 100%;\n    overflow: scroll; }\n  .tags {\n    min-height: auto; }\n  .blog-box {\n    height: auto; }\n  .left-menu, .right-menu {\n    max-width: 100%;\n    width: 100%;\n    flex: auto;\n    text-align: center !important; }\n  div#af-body-343701222 {\n    width: 100%;\n    padding: 0; }\n  .af-element.form-img {\n    width: 100%; }\n  .bodyText span {\n    font-size: 22px !important; }\n  .awebrform form.af-form-wrapper.ng-untouched.ng-pristine.ng-valid {\n    max-width: 400px; } }\n\n@media (max-width: 556px) {\n  .lower_bar .navbar-collapse {\n    top: 58px; }\n  .footer-section .footer1 h2 {\n    margin: 0; } }\n\n@media (max-width: 414px) {\n  .lower_bar nav.navbar.navbar-expand-lg.navbar-light.bg-light {\n    padding: 0px 0; } }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvaG9tZS9DOlxcVXNlcnNcXFdpbmRvd3NcXERlc2t0b3BcXGlvbmljXFx3cC13aXRoLWlvbmljL3NyY1xcYXBwXFxob21lXFxob21lLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNBLG9DQUFvQyxFQUFBOztBQUVwQztFQUNJLFVBQVUsRUFBQTs7QUFFZDtFQUVJLDRCQUE0QjtFQUM1Qiw2QkFBNkI7RUFDN0IsdUNBQXVDO0VBQ3ZDLHNDQUFzQztFQUN0QyxxQ0FBcUM7RUFDckMsb0NBQW9DLEVBQUE7O0FBR3hDO0VBQ0UsZ0JBQWdCO0VBQ2hCLGdCQUFnQixFQUFBOztBQUVsQjtFQUNJLFdBQVcsRUFBQTs7QUFFZjtFQUNJLGFBQWEsRUFBQTs7QUFFakI7RUFFRSxrQkFBa0I7RUFDbEIsY0FBYyxFQUFBOztBQUloQjtFQUNBLGlCQUFpQjtFQUNiLHNCQUFzQixFQUFBOztBQUYxQjtJQUtDLFNBQVM7SUFDTixjQUFjLEVBQUE7O0FBTmxCO0lBU0kscUJBQXFCLEVBQUE7O0FBVHpCO0lBYUksV0FBVztJQUNYLGNBQWMsRUFBQTs7QUFHbEI7RUFDSSxXQUFXO0VBQ1gsZUFBZSxFQUFBOztBQUVuQjtFQUNJLFVBQVUsRUFBQTs7QUFEZDtJQUdJLFlBQVksRUFBQTs7QUFJaEI7RUFDSSxVQUFVLEVBQUE7O0FBRGQ7SUFJSSxlQUFlO0lBQ2xCLHdDQUF3QyxFQUFBOztBQUx6QztJQVFJLGlCQUFpQjtJQUNqQixxQkFBcUI7SUFDckIsV0FBVyxFQUFBOztBQVZmO01BYUcsZUFBZTtNQUNmLHFCQUFxQixFQUFBOztBQWR4QjtNQWlCRSx5QkFBeUI7TUFDekIsZUFBZTtNQUNmLHlCQUF3QjtNQUN4QixnQkFBZ0I7TUFDaEIsb0NBQW9DO01BQ3BDLG9CQUFvQjtNQUNwQiw4QkFBOEI7TUFDOUIsa0JBQWtCLEVBQUE7O0FBeEJwQjs7TUE2QkcsV0FBVztNQUNYLGtCQUFrQjtNQUNsQixzQkFBc0I7TUFDdEIsV0FBVztNQUNYLFdBQVc7TUFDWCxTQUFTO01BQ1QsT0FBTztNQUNQLFFBQVE7TUFDUixZQUFZLEVBQUE7O0FBT2Y7RUFDQyxXQUFVO0VBQ1YseUJBQXdCO0VBQ3hCLGlCQUFnQjtFQUNoQixXQUFXO0VBQ1gsb0NBQW9DLEVBQUE7O0FBTHJDO0lBUUcsU0FBUyxFQUFBOztBQVJaO0lBV0UsdUJBQXFCO0lBQ3JCLG1CQUFrQixFQUFBOztBQVpwQjtJQWVFLG1CQUFrQjtJQUNsQixlQUFjO0lBQ2QsY0FBYTtJQUNiLGlCQUVBLEVBQUE7O0FBcEJGO0lBc0JHLFVBQVM7SUFBQyxTQUFRO0lBQ2xCLGNBQ0QsRUFBQTs7QUF4QkY7SUF5QmlCLGVBQWM7SUFBQyxlQUFjO0lBQUMscUJBQW9CO0lBQUMsY0FBYTtJQUFDLGtDQUFnQztJQUFDLFVBQVM7SUFBQyxtQkFDM0gsRUFBQTs7QUExQkY7SUEyQnNCLGNBQWEsRUFBQTs7QUEzQm5DO0lBNkJLLGdCQUFlO0lBQUMsZUFBYztJQUFDLGtCQUFrQixFQUFBOztBQTdCdEQ7SUErQlMsdUJBQXNCO0lBQUMsc0JBQXFCO0lBQUMsV0FBVTtJQUFDLGVBQWM7SUFBQyxjQUFhO0lBQUMscUJBQW9CO0lBQUMsU0FBUTtJQUFDLGtCQUFpQjtJQUFDLGtCQUFpQjtJQUFDLHlCQUF3QjtJQUFDLGdCQUFlO0lBQXVDLDhCQUE2QixFQUFBOztBQS9CNVE7SUFpQ2UsZ0JBQWU7SUFBQyxXQUFVLEVBQUE7O0FBakN6QztJQXFDRSxXQUFVO0lBQUMseUJBQXdCO0lBQUMsZUFBYztJQUFDLGdCQUFlLEVBQUE7O0FBckNwRTtNQXVDSyxTQUFRO01BQUMsVUFBUyxFQUFBOztBQXZDdkI7TUF5Q1EscUJBQW9CO01BQUMsc0JBQXFCO01BQUMsU0FBUTtNQUFDLFdBQVU7TUFBQyxlQUFjLEVBQUE7O0FBekNyRjtNQTBDVSxXQUFVLEVBQUE7O0FBMUNwQjtNQTRDc0IsaUJBQWdCLEVBQUE7O0FBNUN0QztNQTZDZ0IsV0FBVTtNQUFDLHlCQUF3QjtNQUFDLGdCQUFlO01BQUMsZUFBYyxFQUFBOztBQTdDbEY7TUE4Q2tFLGtDQUFnQztNQUFDLFVBQVMsRUFBQTs7QUFJNUc7RUFDSSxjQUFjO0VBQ2QsZ0NBQWdDLEVBQUE7O0FBR3BDO0VBQ0ksV0FBVyxFQUFBOztBQUdmO0VBQ0ksY0FBYztFQUNkLFdBQVc7RUFDWCxXQUFXO0VBQ1gsV0FBVyxFQUFBOztBQUpmO0lBUUksZUFBZTtJQUNmLGNBQWM7SUFDZCx5QkFBeUI7SUFDekIsZ0JBQWdCO0lBQ2Isc0JBQXNCO0lBQ3pCLG9DQUFvQztJQUNuQyxlQUFlLEVBQUE7O0FBZHBCO0lBaUJJLHNCQUFzQjtJQUN0QixhQUFhLEVBQUE7O0FBbEJqQjtJQXFCSSxhQUFhO0lBQ2Isb0JBQWlCO09BQWpCLGlCQUFpQjtJQUNqQixXQUFXLEVBQUE7O0FBdkJmO0lBMEJJLGVBQWU7SUFDZixjQUFjO0lBQ2QsaUJBQWlCO0lBQ2pCLG9DQUFvQztJQUN2QyxpQkFBaUIsRUFBQTs7QUE5QmxCO0lBaUNFLGlDQUFpQixFQUFBOztBQWpDbkI7SUFvQ0ksV0FBVyxFQUFBOztBQUtmO0VBQ0Msa0JBQWtCO0VBQ2xCLFdBQVU7RUFDUCxtQkFBbUIsRUFBQTs7QUFHdkI7RUFDSSxjQUFjLEVBQUE7O0FBR2xCO0VBQ0ksd0NBQWdCO0VBQ2hCLHNDQUFjO0VBQ2Qsc0NBQWM7RUFDZCx5Q0FBaUI7RUFDakIscUNBQXFDO0VBQ3JDLHNDQUFzQztFQUN0QyxvQ0FBb0M7RUFDcEMsdUNBQXVDLEVBQUE7O0FBRTNDO0VBQ0MsYUFBYSxFQUFBOztBQUVkO0VBQ0MsV0FBVztFQUNSLGtCQUFrQjtFQUNsQixXQUFXLEVBQUE7O0FBRWY7RUFDSSxxQkFBcUI7RUFDckIsZ0JBQWdCLEVBQUE7O0FBRXBCO0VBQ0ksaUJBQWlCLEVBQUE7O0FBRXJCO0VBQ0ksYUFBYSxFQUFBOztBQUVqQjtFQUNJLGVBQWU7RUFDbEIsbUJBQW1CLEVBQUE7O0FBRXBCO0VBQ0kscUJBQXFCO0VBQ3JCLFlBQVksRUFBQTs7QUFHaEIsV0FBQTs7QUFLQTtFQUNJLFlBQVk7RUFDWixrQkFBa0I7RUFDbEIsV0FBVyxFQUFBOztBQUVmO0VBQ0ksa0JBQWtCO0VBQ2xCLFdBQVc7RUFDWCxXQUFXLEVBQUE7O0FBRWY7RUFDSSxVQUFVO0VBQ1YsV0FBVyxFQUFBOztBQUdmO0VBQXVCLFVBQVU7RUFBQyxXQUFXO0VBQUMsbUJBQW1CLEVBQUE7O0FBR2pFO0VBQ0ksV0FBVyxFQUFBOztBQUVmO0VBQ0ksZ0RBQWtFO0VBQ2xFLHNCQUFzQjtFQUN0Qiw0QkFBNEIsRUFBQTs7QUFFaEM7RUFDSSxjQUFjLEVBQUE7O0FBRWxCO0VBQ0kseUJBQXlCLEVBQUE7O0FBRTdCLDhCQUFBOztBQUVBO0VBQ0E7SUFDSSx5QkFBeUI7SUFDekIsMEJBQTBCLEVBQUE7RUFFOUI7SUFDRSx1QkFBQTtJQUNELGVBQWUsRUFBQTtFQUVoQjtJQUNDLGlCQUFpQixFQUFBO0VBRWxCO0lBQ0ksY0FBYyxFQUFBLEVBQ2pCOztBQUVEO0VBQ0M7SUFDRyxhQUFhLEVBQUEsRUFDaEI7O0FBRUQ7RUFDQTtJQUNDLFlBQVk7SUFDVCxXQUFXO0lBQ1gsa0JBQWtCO0lBQ2xCLE9BQU87SUFDUCxRQUFRLEVBQUE7RUFFWjtJQUNDLFdBQVc7SUFDWCxZQUFZO0lBQ1osaUJBQWlCLEVBQUE7RUFFbEI7SUFDQyxrQkFBa0I7SUFDbEIsVUFBVTtJQUNWLHNCQUFzQjtJQUN0QixZQUFZO0lBQ1osV0FBVyxFQUFBO0VBRVo7SUFDSSxjQUFjLEVBQUE7RUFFbEI7SUFDQyxzQkFBc0IsRUFBQTtFQUV2QjtJQUNDLGVBQWUsRUFBQTtFQUVoQjtJQUNJLGFBQWEsRUFBQTtFQUVqQjtJQUNDLGtCQUFrQixFQUFBO0VBRW5CO0lBQ0MsbUJBQW1CLEVBQUE7RUFFcEI7SUFDSSxhQUFhLEVBQUE7RUFFakI7SUFDSSxVQUFVO0lBQ1YsUUFBUSxFQUFBLEVBQ1g7O0FBR0Q7RUFDQTtJQUNDLGVBQWUsRUFBQTtFQUVoQjtJQUNDLGVBQWUsRUFBQTtFQUVoQjtJQUNDLFlBQVksRUFBQTtFQUViO0lBQ0MsU0FBUyxFQUFBO0VBR1Y7SUFDQyxvQkFBQTtJQUNBLG1CQUFtQixFQUFBO0VBRXBCO0lBQ0MsZ0JBQWdCLEVBQUE7RUFHakI7SUFDQyxrQkFBa0IsRUFBQTtFQUVuQjtJQUNDLFdBQVc7SUFDWCxlQUFlO0lBQ2YsZ0JBQWdCLEVBQUE7RUFFakI7SUFDQyxnQkFBZ0IsRUFBQTtFQUVqQjtJQUNJLFlBQVksRUFBQTtFQUVoQjtJQUNJLGVBQWdCO0lBQ2hCLFdBQVc7SUFDWCxVQUFVO0lBQ1YsNkJBQTZCLEVBQUE7RUFFakM7SUFDSSxXQUFXO0lBQ1gsVUFBVSxFQUFBO0VBRWQ7SUFDSSxXQUFXLEVBQUE7RUFFZjtJQUNJLDBCQUEwQixFQUFBO0VBRTlCO0lBQ0ksZ0JBQWdCLEVBQUEsRUFDbkI7O0FBSUQ7RUFDQTtJQUNJLFNBQVMsRUFBQTtFQUViO0lBQ0MsU0FBUyxFQUFBLEVBQ1Q7O0FBR0Q7RUFDQTtJQUNDLGNBQWMsRUFBQSxFQUNkIiwiZmlsZSI6InNyYy9hcHAvaG9tZS9ob21lLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImJvZHl7XHJcbmZvbnQtZmFtaWx5OiAnT3BlbiBTYW5zJywgc2Fucy1zZXJpZjtcclxufVxyXG51bCB7XHJcbiAgICBwYWRkaW5nOiAwO1xyXG59XHJcbmlvbi1jb250ZW50e1xyXG5cdC5pbm5lci1zY3JvbGwge1xyXG4gICAgcGFkZGluZy1sZWZ0OiAwcHggIWltcG9ydGFudDtcclxuICAgIHBhZGRpbmctcmlnaHQ6IDBweCAhaW1wb3J0YW50O1xyXG4gICAgLXdlYmtpdC1wYWRkaW5nLXN0YXJ0OiB1bnNldCAhaW1wb3J0YW50O1xyXG4gICAgcGFkZGluZy1pbmxpbmUtc3RhcnQ6IHVuc2V0ICFpbXBvcnRhbnQ7XHJcbiAgICAtd2Via2l0LXBhZGRpbmctZW5kOiB1bnNldCAhaW1wb3J0YW50O1xyXG4gICAgcGFkZGluZy1pbmxpbmUtZW5kOiB1bnNldCAhaW1wb3J0YW50O1xyXG59XHJcbn0gXHJcbi53ZWxjb21lLWNhcmQgaW9uLWltZyB7XHJcbiAgbWF4LWhlaWdodDogMzV2aDtcclxuICBvdmVyZmxvdzogaGlkZGVuO1xyXG59XHJcbi5iYW5uZXItaW1nIGltZyB7XHJcbiAgICB3aWR0aDogMTAwJTtcclxufVxyXG4ubWVudS10eXBlLW92ZXJsYXkubWVudS1lbmFibGVkLm1lbnUtc2lkZS1zdGFydC5oeWRyYXRlZC5zcGxpdC1wYW5lLXNpZGUubWVudS1wYW5lLXZpc2libGUge1xyXG4gICAgZGlzcGxheTogbm9uZTtcclxufVxyXG5hcHAtaG9tZSB7XHJcblx0Lmlvbi1wYWdlIHtcclxuXHRcdHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuXHRcdGRpc3BsYXk6IHVuc2V0O1xyXG5cdH1cclxufVxyXG5cclxuLnRvcF9iYXIge1xyXG50ZXh0LWFsaWduOiByaWdodDtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICMwMzY7XHJcblx0XHJcbnVse1xyXG5cdG1hcmdpbjogMDtcclxuICAgIHBhZGRpbmc6IDJweCAwO1xyXG59XHJcbnVsIGxpIHtcclxuICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcclxufVxyXG5cclxudWwgbGkgYSB7XHJcbiAgICBjb2xvcjogI2ZmZjtcclxuICAgIHBhZGRpbmc6IDAgN3B4O1xyXG59XHJcbn1cclxuLmhlYWRlci1zZWN0aW9uIHtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgcGFkZGluZzogMTBweCAwO1xyXG59XHJcbi5sb2dvIHtcclxuICAgIHdpZHRoOiA1MCU7XHJcblx0IGltZyB7XHJcbiAgICB3aWR0aDogMzIwcHg7XHJcbn1cclxufVxyXG5cclxuLmxvd2VyX2JhciB7XHJcbiAgICB3aWR0aDogNTAlO1xyXG5cdFxyXG5cdG5hdi5uYXZiYXIubmF2YmFyLWV4cGFuZC1sZy5uYXZiYXItbGlnaHQuYmctbGlnaHQge1xyXG4gICAgcGFkZGluZzogMzJweCAwO1xyXG5cdGJhY2tncm91bmQtY29sb3I6IHRyYW5zcGFyZW50ICFpbXBvcnRhbnQ7XHJcblx0fVxyXG5cdG5hdi5uYXZiYXIgdWwge1xyXG4gICAgdGV4dC1hbGlnbjogcmlnaHQ7XHJcbiAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuXHRcclxuXHRcdCBsaSB7XHJcblx0XHRcdHBhZGRpbmc6IDAgMTBweDtcclxuXHRcdFx0ZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG5cdFx0fVxyXG5cdFx0YSB7XHJcblx0XHR0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xyXG5cdFx0Zm9udC1zaXplOiAxNHB4O1xyXG5cdFx0Y29sb3I6ICMwMDIyMzEhaW1wb3J0YW50O1xyXG5cdFx0Zm9udC13ZWlnaHQ6IDcwMDtcclxuXHRcdGZvbnQtZmFtaWx5OiAnT3BlbiBTYW5zJywgc2Fucy1zZXJpZjtcclxuXHRcdGxldHRlci1zcGFjaW5nOiAuMWVtO1xyXG5cdFx0dHJhbnNpdGlvbjogYWxsIC4zcyBsaW5lYXIgMG1zO1xyXG5cdFx0cG9zaXRpb246IHJlbGF0aXZlO1xyXG5cdFx0XHJcblx0XHR9XHJcblx0XHRsaS5uYXYtaXRlbS5hY3RpdmUgYTo6YWZ0ZXIsXHJcblx0XHQgYTpob3ZlcjphZnRlciB7XHJcblx0XHRcdGNvbnRlbnQ6IFwiXCI7XHJcblx0XHRcdHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuXHRcdFx0YmFja2dyb3VuZC1jb2xvcjogIzAzNjtcclxuXHRcdFx0d2lkdGg6IDIwcHg7XHJcblx0XHRcdGhlaWdodDogNnB4O1xyXG5cdFx0XHRib3R0b206IDA7XHJcblx0XHRcdGxlZnQ6IDA7XHJcblx0XHRcdHJpZ2h0OiAwO1xyXG5cdFx0XHRtYXJnaW46IGF1dG87XHJcblx0XHR9XHJcblx0fVxyXG5cdFxyXG5cdFxyXG59XHJcblxyXG4uZm9vdGVyLXNlY3Rpb257XHJcblx0d2lkdGg6MTAwJTtcclxuXHRiYWNrZ3JvdW5kLWNvbG9yOiNmMWYxZjE7XHJcblx0cGFkZGluZzo2MHB4IDAgMDtcclxuXHRmbG9hdDogbGVmdDtcclxuXHRmb250LWZhbWlseTogJ09wZW4gU2FucycsIHNhbnMtc2VyaWY7XHJcblx0LmZvb3RlcjF7XHJcblx0XHRcdGZpZ3VyZS5pbWFnZSB7XHJcblx0XHRcdG1hcmdpbjogMDtcclxuXHRcdFx0fVxyXG5cdFx0aW1ne1xyXG5cdFx0d2lkdGg6MjQ1cHghaW1wb3J0YW50O1xyXG5cdFx0bWFyZ2luLWJvdHRvbToxMHB4O1xyXG5cdFx0fVxyXG5cdFx0cHtcclxuXHRcdHBhZGRpbmc6MCA1NXB4IDAgMDtcclxuXHRcdGZvbnQtc2l6ZToxNHB4O1xyXG5cdFx0Y29sb3I6IzUwNGY0ZjtcclxuXHRcdGxpbmUtaGVpZ2h0OjI2cHhcclxuXHRcdFxyXG5cdFx0fVxyXG5cdFx0dWwgbGl7XHJcblx0XHRcdHBhZGRpbmc6MDttYXJnaW46MDtcclxuXHRcdFx0ZGlzcGxheTpibG9ja1xyXG5cdFx0fVxyXG5cdFx0YS5uYXZiYXItaXRlbXsgY3Vyc29yOnBvaW50ZXI7Zm9udC1zaXplOjE0cHg7dGV4dC1kZWNvcmF0aW9uOm5vbmU7Y29sb3I6IzUwNGY0ZjtiYWNrZ3JvdW5kOnRyYW5zcGFyZW50IWltcG9ydGFudDtwYWRkaW5nOjA7bWFyZ2luLWJvdHRvbToxMHB4XHJcblx0XHR9XHJcblx0XHRhLm5hdmJhci1pdGVtOmhvdmVye2NvbG9yOiM2YThjMzB9XHJcblx0XHRcclxuXHRcdGgye2ZvbnQtd2VpZ2h0OjcwMDtmb250LXNpemU6MjJweDttYXJnaW46IDAgMCA2MHB4IDA7IH1cclxuXHRcdFxyXG5cdFx0YnV0dG9ue2JhY2tncm91bmQ6dHJhbnNwYXJlbnQ7Ym9yZGVyOjJweCBzb2xpZCAjMDM2O2NvbG9yOiMwMzY7Zm9udC1zaXplOjE0cHg7bGluZS1oZWlnaHQ6MTtsZXR0ZXItc3BhY2luZzouMDJlbTttYXJnaW46MDtwYWRkaW5nOjEwcHggMzhweDtwb3NpdGlvbjpyZWxhdGl2ZTt0ZXh0LXRyYW5zZm9ybTp1cHBlcmNhc2U7Zm9udC13ZWlnaHQ6NzAwOy13ZWJraXQtdHJhbnNpdGlvbjphbGwgLjNzIGxpbmVhciAwbXM7dHJhbnNpdGlvbjphbGwgLjNzIGxpbmVhciAwbXN9XHJcblx0XHRcclxuXHRcdGJ1dHRvbjpob3ZlcntiYWNrZ3JvdW5kOiMwMzY7Y29sb3I6I2ZmZn1cclxuXHRcdFxyXG5cdH1cclxuXHQuYm90dG9tLWZvb3RlcntcclxuXHRcdHdpZHRoOjEwMCU7YmFja2dyb3VuZC1jb2xvcjojZGRlMWRhO3BhZGRpbmc6MjBweCAwO21hcmdpbi10b3A6NjVweDtcclxuXHRcdFxyXG5cdFx0dWx7bWFyZ2luOjA7cGFkZGluZzowfVxyXG5cdFx0XHJcblx0XHR1bCBsaXtkaXNwbGF5OmlubGluZS1ibG9jaztwYWRkaW5nOjAgMTJweCAgMCAwcHg7bWFyZ2luOjA7Y29sb3I6IzAwMDtmb250LXNpemU6MTRweH1cclxuXHRcdHVsIGxpIGF7Y29sb3I6IzAzNjt9XHJcblx0XHRcclxuXHRcdGNvbC1zbS02LnJpZ2h0LW1lbnV7dGV4dC1hbGlnbjpyaWdodH1cclxuXHRcdGEuY3NzLTFkbnd2dTN7Y29sb3I6IzAwMDt0ZXh0LXRyYW5zZm9ybTp1cHBlcmNhc2U7Zm9udC13ZWlnaHQ6NzAwO2ZvbnQtc2l6ZToxNHB4fVxyXG5cdFx0Lm5hdmJhci1zdGFydCBuYXYubmF2YmFyLm5hdmJhci1leHBhbmQtbGcubmF2YmFyLWxpZ2h0LmJnLWxpZ2h0e2JhY2tncm91bmQ6dHJhbnNwYXJlbnQhaW1wb3J0YW50O3BhZGRpbmc6MH1cclxuXHRcclxuXHR9XHJcbn1cclxuLmZvb3RlcjEgYSB7XHJcbiAgICBjb2xvcjogIzUwNGY0ZjtcclxuICAgIHRleHQtZGVjb3JhdGlvbjogbm9uZSAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4uZm9vdGVyMSBhOmhvdmVyIHtcclxuICAgIGNvbG9yOiAjMDM2O1xyXG59XHJcblxyXG5pb24tbGlzdC5tZC5saXN0LW1kLmh5ZHJhdGVkIHtcclxuICAgIG1hcmdpbjogMzVweCAwO1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBmbG9hdDogbGVmdDtcclxuICAgIGNsZWFyOiBib3RoO1xyXG5cdFxyXG5cclxuXHRpb24tY2FyZC10aXRsZS5tZC5oeWRyYXRlZCB7XHJcbiAgICBmb250LXNpemU6IDE2cHg7XHJcbiAgICBjb2xvcjogIzAwMTgyMjtcclxuICAgIHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XHJcbiAgICBmb250LXdlaWdodDogNzAwO1xyXG4gICAgICAgcGFkZGluZzogMTBweCAwIDE1cHggMDtcclxuICAgIGZvbnQtZmFtaWx5OiAnT3BlbiBTYW5zJywgc2Fucy1zZXJpZjtcclxuXHQgICAgbWluLWhlaWdodDogMHB4O1xyXG5cdH1cclxuXHQucG9zdF9ibG9jayB7XHJcbiAgICBib3JkZXI6IDFweCBzb2xpZCAjZGRkO1xyXG4gICAgcGFkZGluZzogMTBweDtcclxufVxyXG5cdC5wb3N0X2Jsb2NrIGltZyB7XHJcbiAgICBoZWlnaHQ6IDE5MHB4O1xyXG4gICAgb2JqZWN0LWZpdDogY292ZXI7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuXHR9XHJcblx0LmRpc2NyaXB0aW9uIHtcclxuICAgIGZvbnQtc2l6ZTogMTRweDtcclxuICAgIGNvbG9yOiAjNzk3Nzc3O1xyXG4gICAgbGluZS1oZWlnaHQ6IDI0cHg7XHJcbiAgICBmb250LWZhbWlseTogJ09wZW4gU2FucycsIHNhbnMtc2VyaWY7XHJcblx0bWluLWhlaWdodDogMTQ1cHg7XHJcbn1cclxuXHRpb24tYnV0dG9uLmlvbi1jb2xvci5pb24tY29sb3ItcHJpbWFyeSB7XHJcblx0XHQtLWlvbi1jb2xvci1iYXNlOiAjMDM2ICFpbXBvcnRhbnQ7XHJcblx0fVxyXG5cdGlvbi1jYXJkLXN1YnRpdGxlLm1kLmh5ZHJhdGVkIHtcclxuICAgIGNvbG9yOiAjMDM2O1xyXG5cdH1cclxuXHJcbn1cclxuIFxyXG5pb24tY29sLm1kLmh5ZHJhdGVkIHtcclxuXHRwYWRkaW5nOiAxMHB4IDEwcHg7XHJcblx0ZmxvYXQ6bGVmdDtcclxuICAgIHZlcnRpY2FsLWFsaWduOiB0b3A7XHJcbn1cclxuXHJcbi5pb24tcGFkZGluZy5jdXN0b20tc2tlbGV0b24ucG9zdC1za2VsZXRvbiB7XHJcbiAgICBtYXJnaW46IDM1cHggMDtcclxufVxyXG5cclxuLmlvbi1wYWRkaW5nLCBbcGFkZGluZ10ge1xyXG4gICAgLS1wYWRkaW5nLXN0YXJ0OiB2YXIoLS1pb24tcGFkZGluZywgMHB4KTtcclxuICAgIC0tcGFkZGluZy1lbmQ6IHZhcigtLWlvbi1wYWRkaW5nLCAwcHgpO1xyXG4gICAgLS1wYWRkaW5nLXRvcDogdmFyKC0taW9uLXBhZGRpbmcsIDBweCk7XHJcbiAgICAtLXBhZGRpbmctYm90dG9tOiB2YXIoLS1pb24tcGFkZGluZywgMHB4KTtcclxuICAgIHBhZGRpbmctbGVmdDogdmFyKC0taW9uLXBhZGRpbmcsIDBweCk7XHJcbiAgICBwYWRkaW5nLXJpZ2h0OiB2YXIoLS1pb24tcGFkZGluZywgMHB4KTtcclxuICAgIHBhZGRpbmctdG9wOiB2YXIoLS1pb24tcGFkZGluZywgMHB4KTtcclxuICAgIHBhZGRpbmctYm90dG9tOiB2YXIoLS1pb24tcGFkZGluZywgMHB4KTtcclxufVxyXG5idXR0b246Zm9jdXMge1xyXG5cdG91dGxpbmU6IG5vbmU7XHJcbn1cclxuLmxvYWRtb3JlLXBhZ2Uge1xyXG5cdHdpZHRoOiAxMDAlO1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgY2xlYXI6IGJvdGg7XHJcbn1cclxuLmxvYWRtb3JlIHtcdCAgIFxyXG4gICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG4gICAgbWFyZ2luLXRvcDogMzBweDtcclxufVxyXG4ucmlnaHQtbWVudSB7XHJcbiAgICB0ZXh0LWFsaWduOiByaWdodDtcclxufVxyXG4uYmxvZy1ib3gge1xyXG4gICAgaGVpZ2h0OiAyNjBweDtcclxufVxyXG4udGFncyB7XHJcbiAgICBtaW4taGVpZ2h0OiAwcHg7XHJcblx0bWFyZ2luLWJvdHRvbTogMTBweDtcclxufVxyXG4ucG9zdF9ibG9jayBhIHtcclxuICAgIHRleHQtZGVjb3JhdGlvbjogbm9uZTtcclxuICAgIGNvbG9yOiB1bnNldDtcclxufVxyXG5cclxuLypmb3JtIGNzcyovXHJcblxyXG5cclxuXHJcblxyXG5kaXYjYWYtZm9ybS0zNDM3MDEyMjIgaW1nIHtcclxuICAgIG1hcmdpbjogYXV0bztcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG59XHJcbmRpdiNhZi1oZWFkZXItMzQzNzAxMjIyIHtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgZmxvYXQ6IGxlZnQ7XHJcbn1cclxuLmFmLWVsZW1lbnQuZm9ybS1pbWcge1xyXG4gICAgd2lkdGg6IDUwJTtcclxuICAgIGZsb2F0OiBsZWZ0O1xyXG59XHJcblxyXG5kaXYjYWYtYm9keS0zNDM3MDEyMjIge3dpZHRoOiA1MCU7ZmxvYXQ6IGxlZnQ7cGFkZGluZzogMCAwIDAgMzBweDt9XHJcblxyXG5cclxuZGl2I2FmLWJvZHktMzQzNzAxMjIyIC5hZi1lbGVtZW50IHtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG59XHJcbi5hd2VicmZvcm0ge1xyXG4gICAgYmFja2dyb3VuZC1pbWFnZTogdXJsKC4uLy4uL2Fzc2V0cy9pbWFnZXMvcmVwYWlyX3NlY3Rpb25fYmFjay5qcGcpO1xyXG4gICAgYmFja2dyb3VuZC1zaXplOiBjb3ZlcjtcclxuICAgIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XHJcbn1cclxuLmJ1dHRvbkNvbnRhaW5lciBpbnB1dC5zdWJtaXQge1xyXG4gICAgbWFyZ2luOiAxNXB4IDA7XHJcbn1cclxuZGl2I2FmLWJvZHktMzQzNzAxMjIyIHtcclxuICAgIHBhZGRpbmc6IDM0cHggMCAxN3B4IDMwcHg7XHJcbn1cclxuLyptZWRpYSBxdWVyeSBzdGFydCBmcm9tIGhlcmUqL1xyXG5cclxuQG1lZGlhKG1heC13aWR0aDoxMTk5cHgpe1xyXG4ubG93ZXJfYmFyIG5hdi5uYXZiYXIgdWwgYSB7XHJcbiAgICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xyXG4gICAgZm9udC1zaXplOiAxMnB4ICFpbXBvcnRhbnQ7XHJcbn1cclxuaW9uLWxpc3QubWQubGlzdC1tZC5oeWRyYXRlZCBpb24tY2FyZC10aXRsZS5tZC5oeWRyYXRlZCB7XHJcbiAgLyogIG1pbi1oZWlnaHQ6IDYwcHg7ICovXHJcblx0Zm9udC1zaXplOiAxNHB4O1xyXG59XHJcbmlvbi1saXN0Lm1kLmxpc3QtbWQuaHlkcmF0ZWQgLmRpc2NyaXB0aW9uIHtcclxuXHRtaW4taGVpZ2h0OiAxNzBweDtcclxufVxyXG4ubG93ZXJfYmFyIG5hdi5uYXZiYXIgdWwgbGkge1xyXG4gICAgcGFkZGluZzogMCA2cHg7XHJcbn1cclxufVxyXG5AbWVkaWEgKG1pbi13aWR0aDo5OTFweClhbmQgKG1heC13aWR0aDoxMjAwcHgpe1xyXG5cdC5ibG9nLWJveCB7XHJcbiAgICBoZWlnaHQ6IDMxMHB4O1xyXG59XHJcbn1cclxuQG1lZGlhIChtYXgtd2lkdGg6OTkxcHgpe1xyXG4ubG93ZXJfYmFyIG5hdi5uYXZiYXIubmF2YmFyLWV4cGFuZC1sZy5uYXZiYXItbGlnaHQuYmctbGlnaHQge1xyXG5cdGZsb2F0OiByaWdodDtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgbGVmdDogMDtcclxuICAgIHJpZ2h0OiAwO1xyXG59XHRcclxuLmxvd2VyX2JhciAubmF2YmFyLXRvZ2dsZXIge1xyXG5cdHdpZHRoOiAxMDAlO1xyXG5cdGJvcmRlcjogbm9uZTtcclxuXHR0ZXh0LWFsaWduOiByaWdodDtcclxufVxyXG4ubG93ZXJfYmFyIC5uYXZiYXItY29sbGFwc2Uge1xyXG5cdHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuXHR0b3A6IDEwMXB4O1xyXG5cdGJhY2tncm91bmQtY29sb3I6ICMwMzY7XHJcblx0ei1pbmRleDogOTk5O1xyXG5cdHdpZHRoOiAxMDAlO1xyXG59XHRcclxuLmxvd2VyX2JhciBuYXYubmF2YmFyIHVsIGxpIHtcclxuICAgIGRpc3BsYXk6IGJsb2NrO1xyXG59XHJcbi5sb3dlcl9iYXIgbmF2Lm5hdmJhciB1bCBhIHtcclxuXHRjb2xvcjogI2ZmZiAhaW1wb3J0YW50O1xyXG59XHJcbi5sb3dlcl9iYXIgbmF2Lm5hdmJhciB1bCB7XHJcblx0cGFkZGluZzogMTVweCAwO1xyXG59XHJcbi5sb3dlcl9iYXIgbmF2Lm5hdmJhciB1bCBhOmhvdmVyOjphZnRlciB7XHJcbiAgICBjb250ZW50OiBub25lO1xyXG59XHJcbi5mb290ZXItc2VjdGlvbiAuZm9vdGVyMSBidXR0b24ge1xyXG5cdHBhZGRpbmc6IDEwcHggMjRweDtcclxufVxyXG4uZm9vdGVyLXNlY3Rpb24gLmZvb3RlcjEgcCB7XHJcblx0cGFkZGluZzogMCAxNXB4IDAgMDtcclxufVxyXG4uYmxvZy1ib3h7XHJcbiAgICBoZWlnaHQ6IDMwMHB4O1xyXG59XHJcbi5sb3dlcl9iYXIgbmF2Lm5hdmJhciB1bCBsaS5uYXYtaXRlbS5hY3RpdmUgYTo6YWZ0ZXIsIC5sb3dlcl9iYXIgbmF2Lm5hdmJhciB1bCBhOmhvdmVyOmFmdGVyIHtcclxuICAgIGxlZnQ6IGF1dG87XHJcbiAgICByaWdodDogMDtcclxufVxyXG59XHJcblxyXG5AbWVkaWEobWF4LXdpZHRoOjc2N3B4KXtcclxuLmxvd2VyX2JhciBuYXYubmF2YmFyLm5hdmJhci1leHBhbmQtbGcubmF2YmFyLWxpZ2h0LmJnLWxpZ2h0IHtcclxuXHRwYWRkaW5nOiAxNnB4IDA7XHJcbn1cdFxyXG4ubG9nbyB7XHJcblx0cGFkZGluZzogMCAxMHB4O1xyXG59XHJcbi5sb2dvIGltZyB7XHJcblx0d2lkdGg6IDIwMHB4O1xyXG59XHRcclxuLmxvd2VyX2JhciAubmF2YmFyLWNvbGxhcHNlIHtcclxuXHR0b3A6IDcwcHg7XHJcbn1cclxuXHJcbmlvbi1saXN0Lm1kLmxpc3QtbWQuaHlkcmF0ZWQgaW9uLWNhcmQtdGl0bGUubWQuaHlkcmF0ZWQge1xyXG5cdC8qbWluLWhlaWdodDogMTAwJTsqL1xyXG5cdG1hcmdpbi1ib3R0b206IDEwcHg7XHJcbn1cclxuaW9uLWxpc3QubWQubGlzdC1tZC5oeWRyYXRlZCAuZGlzY3JpcHRpb24ge1xyXG5cdG1pbi1oZWlnaHQ6IDEwMCU7XHJcblx0XHJcbn1cclxuLnJpZ2h0LW1lbnUge1xyXG5cdHRleHQtYWxpZ246IGNlbnRlcjtcclxufVxyXG4ubG9hZG1vcmUtcGFnZSB7XHJcblx0d2lkdGg6IDEwMCU7XHJcblx0bWF4LXdpZHRoOiAxMDAlO1xyXG5cdG92ZXJmbG93OiBzY3JvbGw7XHJcbn1cclxuLnRhZ3Mge1xyXG5cdG1pbi1oZWlnaHQ6IGF1dG87XHJcbn1cclxuLmJsb2ctYm94IHtcclxuICAgIGhlaWdodDogYXV0bztcclxufVxyXG4ubGVmdC1tZW51LCAucmlnaHQtbWVudSB7XHJcbiAgICBtYXgtd2lkdGg6IDEwMCUgO1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBmbGV4OiBhdXRvO1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyICFpbXBvcnRhbnQ7XHJcbn1cclxuZGl2I2FmLWJvZHktMzQzNzAxMjIyIHtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgcGFkZGluZzogMDtcclxufVxyXG4uYWYtZWxlbWVudC5mb3JtLWltZyB7XHJcbiAgICB3aWR0aDogMTAwJTtcclxufVxyXG4uYm9keVRleHQgc3BhbiB7XHJcbiAgICBmb250LXNpemU6IDIycHggIWltcG9ydGFudDtcclxufVxyXG4uYXdlYnJmb3JtIGZvcm0uYWYtZm9ybS13cmFwcGVyLm5nLXVudG91Y2hlZC5uZy1wcmlzdGluZS5uZy12YWxpZCB7XHJcbiAgICBtYXgtd2lkdGg6IDQwMHB4O1xyXG59XHJcblxyXG5cclxufVxyXG5AbWVkaWEobWF4LXdpZHRoOjU1NnB4KXtcclxuLmxvd2VyX2JhciAubmF2YmFyLWNvbGxhcHNlIHtcclxuICAgIHRvcDogNThweDtcclxufVxyXG4uZm9vdGVyLXNlY3Rpb24gLmZvb3RlcjEgaDIge1xyXG5cdG1hcmdpbjogMDtcclxufVxyXG5cclxufVxyXG5AbWVkaWEobWF4LXdpZHRoOjQxNHB4KXtcclxuLmxvd2VyX2JhciBuYXYubmF2YmFyLm5hdmJhci1leHBhbmQtbGcubmF2YmFyLWxpZ2h0LmJnLWxpZ2h0e1xyXG5cdHBhZGRpbmc6IDBweCAwO1xyXG59XHRcclxuXHJcbn0iXX0= */"

/***/ }),

/***/ "./src/app/home/home.page.ts":
/*!***********************************!*\
  !*** ./src/app/home/home.page.ts ***!
  \***********************************/
/*! exports provided: HomePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomePage", function() { return HomePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _shared_data_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../shared/data.service */ "./src/app/shared/data.service.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _angular_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/http */ "./node_modules/@angular/http/fesm5/http.js");
/* harmony import */ var rxjs_add_operator_map__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/add/operator/map */ "./node_modules/rxjs-compat/_esm5/add/operator/map.js");
/* harmony import */ var _providers_seo_seo__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../providers/seo/seo */ "./src/providers/seo/seo.ts");







var ENDPOINT_URL = _environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].endpointURL;
var HomePage = /** @class */ (function () {
    function HomePage(dataService, http, htmlheadService) {
        this.dataService = dataService;
        this.http = http;
        this.htmlheadService = htmlheadService;
        this.Base_url = _environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].endpointURL;
        this.dateFormat = _environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].dateFormat;
        this.skeletion = true;
        this.section_web = false;
        /*************sco service**************/
        var title = 'THE CODE PRACTICE';
        var description = 'THE CODE PRACTICE';
        var keywords = 'THE CODE PRACTICE';
        var img = 'assets/images/icon.png';
        this.htmlheadService.addMeta(title, description, keywords, img);
        this.htmlheadService.addMetaOg(title, description, keywords, img);
        this.htmlheadService.addMetaTwitter(title, description, keywords, img);
    }
    HomePage.prototype.ngOnInit = function () {
        var _this = this;
        this.http.get(ENDPOINT_URL + 'wp/v2/posts?filter[posts_per_page]=30')
            .map(function (response) { return response.json(); })
            .subscribe(function (data) {
            _this.items = data;
            console.log(_this.items);
            _this.skeletion = false;
            _this.section_web = true;
        });
    };
    HomePage.prototype.onChangePage = function (pageOfItems) {
        // update current page of items
        this.pageOfItems = pageOfItems;
    };
    HomePage.prototype.strip_html_tags = function (str) {
        if ((str === null) || (str === ''))
            return false;
        else
            str = str.toString();
        return str.replace(/<[^>]*>/g, '');
    };
    HomePage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-home',
            template: __webpack_require__(/*! ./home.page.html */ "./src/app/home/home.page.html"),
            styles: [__webpack_require__(/*! ./home.page.scss */ "./src/app/home/home.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_shared_data_service__WEBPACK_IMPORTED_MODULE_2__["DataService"], _angular_http__WEBPACK_IMPORTED_MODULE_4__["Http"], _providers_seo_seo__WEBPACK_IMPORTED_MODULE_6__["HtmlheadService"]])
    ], HomePage);
    return HomePage;
}());



/***/ })

}]);
//# sourceMappingURL=home-home-module.js.map