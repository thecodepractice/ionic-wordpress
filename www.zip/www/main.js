(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./node_modules/@ionic/core/dist/esm/es5/build lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$":
/*!*********************************************************************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm/es5/build lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ namespace object ***!
  \*********************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./0jv2gqw7.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/0jv2gqw7.entry.js",
		"common",
		10
	],
	"./0jv2gqw7.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/0jv2gqw7.sc.entry.js",
		"common",
		11
	],
	"./1hlqf399.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/1hlqf399.entry.js",
		"common",
		54
	],
	"./1hlqf399.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/1hlqf399.sc.entry.js",
		"common",
		55
	],
	"./1smtjtrp.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/1smtjtrp.entry.js",
		"common",
		56
	],
	"./1smtjtrp.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/1smtjtrp.sc.entry.js",
		"common",
		57
	],
	"./2fikn3fc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/2fikn3fc.entry.js",
		0,
		"common",
		128
	],
	"./2fikn3fc.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/2fikn3fc.sc.entry.js",
		0,
		"common",
		129
	],
	"./3ul05w05.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/3ul05w05.entry.js",
		"common",
		58
	],
	"./3ul05w05.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/3ul05w05.sc.entry.js",
		"common",
		59
	],
	"./4zh8hiut.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/4zh8hiut.entry.js",
		0,
		"common",
		130
	],
	"./4zh8hiut.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/4zh8hiut.sc.entry.js",
		0,
		"common",
		131
	],
	"./5esrbynz.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/5esrbynz.entry.js",
		"common",
		102
	],
	"./5esrbynz.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/5esrbynz.sc.entry.js",
		"common",
		103
	],
	"./5ptcnpes.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/5ptcnpes.entry.js",
		"common",
		12
	],
	"./5ptcnpes.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/5ptcnpes.sc.entry.js",
		"common",
		13
	],
	"./5pwuvxkr.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/5pwuvxkr.entry.js",
		"common",
		60
	],
	"./5pwuvxkr.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/5pwuvxkr.sc.entry.js",
		"common",
		61
	],
	"./5vxaf0jn.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/5vxaf0jn.entry.js",
		"common",
		62
	],
	"./5vxaf0jn.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/5vxaf0jn.sc.entry.js",
		"common",
		63
	],
	"./6dsdnxyn.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/6dsdnxyn.entry.js",
		"common",
		64
	],
	"./6dsdnxyn.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/6dsdnxyn.sc.entry.js",
		"common",
		65
	],
	"./6evzjzxd.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/6evzjzxd.entry.js",
		0,
		"common",
		132
	],
	"./6evzjzxd.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/6evzjzxd.sc.entry.js",
		0,
		"common",
		133
	],
	"./6kgso7pq.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/6kgso7pq.entry.js",
		"common",
		14
	],
	"./6kgso7pq.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/6kgso7pq.sc.entry.js",
		"common",
		15
	],
	"./7xggbwe8.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/7xggbwe8.entry.js",
		"common",
		66
	],
	"./7xggbwe8.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/7xggbwe8.sc.entry.js",
		"common",
		67
	],
	"./8odyguue.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/8odyguue.entry.js",
		"common",
		68
	],
	"./8odyguue.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/8odyguue.sc.entry.js",
		"common",
		69
	],
	"./aavh7iu1.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/aavh7iu1.entry.js",
		0,
		"common",
		134
	],
	"./aavh7iu1.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/aavh7iu1.sc.entry.js",
		0,
		"common",
		135
	],
	"./admmxern.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/admmxern.entry.js",
		"common",
		70
	],
	"./admmxern.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/admmxern.sc.entry.js",
		"common",
		71
	],
	"./apfh3flu.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/apfh3flu.entry.js",
		"common",
		16
	],
	"./apfh3flu.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/apfh3flu.sc.entry.js",
		"common",
		17
	],
	"./b3nyp0te.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/b3nyp0te.entry.js",
		"common",
		104
	],
	"./b3nyp0te.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/b3nyp0te.sc.entry.js",
		"common",
		105
	],
	"./bngjpe45.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/bngjpe45.entry.js",
		"common",
		18
	],
	"./bngjpe45.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/bngjpe45.sc.entry.js",
		"common",
		19
	],
	"./cwd9g9my.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/cwd9g9my.entry.js",
		"common",
		100
	],
	"./cwd9g9my.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/cwd9g9my.sc.entry.js",
		"common",
		101
	],
	"./dsb5jv5r.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/dsb5jv5r.entry.js",
		"common",
		20
	],
	"./dsb5jv5r.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/dsb5jv5r.sc.entry.js",
		"common",
		21
	],
	"./e2nyp2ge.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/e2nyp2ge.entry.js",
		"common",
		22
	],
	"./e2nyp2ge.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/e2nyp2ge.sc.entry.js",
		"common",
		23
	],
	"./ejapjnva.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ejapjnva.entry.js",
		"common",
		72
	],
	"./ejapjnva.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ejapjnva.sc.entry.js",
		"common",
		73
	],
	"./fuq8m3zo.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/fuq8m3zo.entry.js",
		"common",
		24
	],
	"./fuq8m3zo.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/fuq8m3zo.sc.entry.js",
		"common",
		25
	],
	"./fwzyk2t9.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/fwzyk2t9.entry.js",
		"common",
		26
	],
	"./fwzyk2t9.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/fwzyk2t9.sc.entry.js",
		"common",
		27
	],
	"./g1fmjj6r.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/g1fmjj6r.entry.js",
		"common",
		28
	],
	"./g1fmjj6r.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/g1fmjj6r.sc.entry.js",
		"common",
		29
	],
	"./g7y3qohv.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/g7y3qohv.entry.js",
		0,
		"common",
		138
	],
	"./g7y3qohv.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/g7y3qohv.sc.entry.js",
		0,
		"common",
		139
	],
	"./gbcxupo7.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/gbcxupo7.entry.js",
		"common",
		74
	],
	"./gbcxupo7.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/gbcxupo7.sc.entry.js",
		"common",
		75
	],
	"./gtqqbhae.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/gtqqbhae.entry.js",
		"common",
		30
	],
	"./gtqqbhae.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/gtqqbhae.sc.entry.js",
		"common",
		31
	],
	"./helxzsef.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/helxzsef.entry.js",
		140
	],
	"./helxzsef.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/helxzsef.sc.entry.js",
		141
	],
	"./hg9mfbbd.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/hg9mfbbd.entry.js",
		"common",
		76
	],
	"./hg9mfbbd.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/hg9mfbbd.sc.entry.js",
		"common",
		77
	],
	"./hqq2qdqe.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/hqq2qdqe.entry.js",
		0,
		"common",
		142
	],
	"./hqq2qdqe.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/hqq2qdqe.sc.entry.js",
		0,
		"common",
		143
	],
	"./i5bu78vq.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/i5bu78vq.entry.js",
		"common",
		78
	],
	"./i5bu78vq.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/i5bu78vq.sc.entry.js",
		"common",
		79
	],
	"./ibsc94yw.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ibsc94yw.entry.js",
		"common",
		106
	],
	"./ibsc94yw.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ibsc94yw.sc.entry.js",
		"common",
		107
	],
	"./ipk81gk6.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ipk81gk6.entry.js",
		144
	],
	"./ipk81gk6.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ipk81gk6.sc.entry.js",
		145
	],
	"./iqlhkurd.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/iqlhkurd.entry.js",
		"common",
		80
	],
	"./iqlhkurd.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/iqlhkurd.sc.entry.js",
		"common",
		81
	],
	"./isuxxasv.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/isuxxasv.entry.js",
		"common",
		82
	],
	"./isuxxasv.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/isuxxasv.sc.entry.js",
		"common",
		83
	],
	"./j241fzpw.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/j241fzpw.entry.js",
		"common",
		32
	],
	"./j241fzpw.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/j241fzpw.sc.entry.js",
		"common",
		33
	],
	"./j6a9duez.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/j6a9duez.entry.js",
		"common",
		34
	],
	"./j6a9duez.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/j6a9duez.sc.entry.js",
		"common",
		35
	],
	"./j9sczdb9.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/j9sczdb9.entry.js",
		"common",
		36
	],
	"./j9sczdb9.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/j9sczdb9.sc.entry.js",
		"common",
		37
	],
	"./jpkvsu5y.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/jpkvsu5y.entry.js",
		"common",
		112
	],
	"./jpkvsu5y.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/jpkvsu5y.sc.entry.js",
		"common",
		113
	],
	"./k4hoilf4.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/k4hoilf4.entry.js",
		"common",
		84
	],
	"./k4hoilf4.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/k4hoilf4.sc.entry.js",
		"common",
		85
	],
	"./ksgex3rj.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ksgex3rj.entry.js",
		"common",
		38
	],
	"./ksgex3rj.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ksgex3rj.sc.entry.js",
		"common",
		39
	],
	"./kwsaahen.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/kwsaahen.entry.js",
		2,
		"common",
		146
	],
	"./kwsaahen.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/kwsaahen.sc.entry.js",
		2,
		"common",
		147
	],
	"./mri9bdlj.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/mri9bdlj.entry.js",
		148
	],
	"./mri9bdlj.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/mri9bdlj.sc.entry.js",
		149
	],
	"./okzvvz1s.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/okzvvz1s.entry.js",
		"common",
		40
	],
	"./okzvvz1s.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/okzvvz1s.sc.entry.js",
		"common",
		41
	],
	"./omfdyboy.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/omfdyboy.entry.js",
		"common",
		114
	],
	"./omfdyboy.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/omfdyboy.sc.entry.js",
		"common",
		115
	],
	"./oopkmdhe.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/oopkmdhe.entry.js",
		0,
		"common",
		108
	],
	"./oopkmdhe.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/oopkmdhe.sc.entry.js",
		0,
		"common",
		109
	],
	"./paaaniyp.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/paaaniyp.entry.js",
		"common",
		116
	],
	"./paaaniyp.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/paaaniyp.sc.entry.js",
		"common",
		117
	],
	"./pcvyposn.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/pcvyposn.entry.js",
		"common",
		42
	],
	"./pcvyposn.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/pcvyposn.sc.entry.js",
		"common",
		43
	],
	"./qjwxr7dv.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/qjwxr7dv.entry.js",
		"common",
		44
	],
	"./qjwxr7dv.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/qjwxr7dv.sc.entry.js",
		"common",
		45
	],
	"./qmw4agos.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/qmw4agos.entry.js",
		0,
		"common",
		150
	],
	"./qmw4agos.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/qmw4agos.sc.entry.js",
		0,
		"common",
		151
	],
	"./qoe6pe8v.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/qoe6pe8v.entry.js",
		"common",
		46
	],
	"./qoe6pe8v.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/qoe6pe8v.sc.entry.js",
		"common",
		47
	],
	"./qqusykhh.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/qqusykhh.entry.js",
		"common",
		86
	],
	"./qqusykhh.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/qqusykhh.sc.entry.js",
		"common",
		87
	],
	"./qutdmiwk.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/qutdmiwk.entry.js",
		0,
		"common",
		152
	],
	"./qutdmiwk.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/qutdmiwk.sc.entry.js",
		0,
		"common",
		153
	],
	"./qvljddf6.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/qvljddf6.entry.js",
		0,
		"common",
		154
	],
	"./qvljddf6.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/qvljddf6.sc.entry.js",
		0,
		"common",
		155
	],
	"./rcclotvr.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/rcclotvr.entry.js",
		2,
		"common",
		156
	],
	"./rcclotvr.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/rcclotvr.sc.entry.js",
		2,
		"common",
		157
	],
	"./rkecsmgc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/rkecsmgc.entry.js",
		"common",
		118
	],
	"./rkecsmgc.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/rkecsmgc.sc.entry.js",
		"common",
		119
	],
	"./rrpxfm2a.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/rrpxfm2a.entry.js",
		158
	],
	"./rrpxfm2a.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/rrpxfm2a.sc.entry.js",
		159
	],
	"./rvwuhvz4.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/rvwuhvz4.entry.js",
		0,
		"common",
		160
	],
	"./rvwuhvz4.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/rvwuhvz4.sc.entry.js",
		0,
		"common",
		161
	],
	"./sbcfgnyq.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/sbcfgnyq.entry.js",
		"common",
		120
	],
	"./sbcfgnyq.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/sbcfgnyq.sc.entry.js",
		"common",
		121
	],
	"./sjwxpows.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/sjwxpows.entry.js",
		"common",
		122
	],
	"./sjwxpows.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/sjwxpows.sc.entry.js",
		"common",
		123
	],
	"./tlbladaf.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/tlbladaf.entry.js",
		"common",
		48
	],
	"./tlbladaf.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/tlbladaf.sc.entry.js",
		"common",
		49
	],
	"./tsx41s3c.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/tsx41s3c.entry.js",
		"common",
		50
	],
	"./tsx41s3c.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/tsx41s3c.sc.entry.js",
		"common",
		51
	],
	"./txpe5bol.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/txpe5bol.entry.js",
		"common",
		88
	],
	"./txpe5bol.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/txpe5bol.sc.entry.js",
		"common",
		89
	],
	"./vhwyavqm.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/vhwyavqm.entry.js",
		"common",
		52
	],
	"./vhwyavqm.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/vhwyavqm.sc.entry.js",
		"common",
		53
	],
	"./w6supv7p.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/w6supv7p.entry.js",
		"common",
		90
	],
	"./w6supv7p.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/w6supv7p.sc.entry.js",
		"common",
		91
	],
	"./wjdsdnuu.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/wjdsdnuu.entry.js",
		"common",
		92
	],
	"./wjdsdnuu.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/wjdsdnuu.sc.entry.js",
		"common",
		93
	],
	"./wpzpc9xw.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/wpzpc9xw.entry.js",
		0,
		"common",
		110
	],
	"./wpzpc9xw.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/wpzpc9xw.sc.entry.js",
		0,
		"common",
		111
	],
	"./xar48p4b.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/xar48p4b.entry.js",
		"common",
		124
	],
	"./xar48p4b.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/xar48p4b.sc.entry.js",
		"common",
		125
	],
	"./xrssylnk.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/xrssylnk.entry.js",
		0,
		"common",
		162
	],
	"./xrssylnk.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/xrssylnk.sc.entry.js",
		0,
		"common",
		163
	],
	"./ylecf5ox.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ylecf5ox.entry.js",
		"common",
		94
	],
	"./ylecf5ox.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ylecf5ox.sc.entry.js",
		"common",
		95
	],
	"./yxoiyuhs.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/yxoiyuhs.entry.js",
		"common",
		96
	],
	"./yxoiyuhs.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/yxoiyuhs.sc.entry.js",
		"common",
		97
	],
	"./zc63qizl.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/zc63qizl.entry.js",
		"common",
		98
	],
	"./zc63qizl.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/zc63qizl.sc.entry.js",
		"common",
		99
	],
	"./ziv0mko0.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ziv0mko0.entry.js",
		"common",
		126
	],
	"./ziv0mko0.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ziv0mko0.sc.entry.js",
		"common",
		127
	],
	"./zxjlzr69.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/zxjlzr69.entry.js",
		0,
		"common",
		164
	],
	"./zxjlzr69.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/zxjlzr69.sc.entry.js",
		0,
		"common",
		165
	]
};
function webpackAsyncContext(req) {
	var ids = map[req];
	if(!ids) {
		return Promise.resolve().then(function() {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(function() {
		var id = ids[0];
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = function webpackAsyncContextKeys() {
	return Object.keys(map);
};
webpackAsyncContext.id = "./node_modules/@ionic/core/dist/esm/es5/build lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$";
module.exports = webpackAsyncContext;

/***/ }),

/***/ "./src/$$_lazy_route_resource lazy recursive":
/*!**********************************************************!*\
  !*** ./src/$$_lazy_route_resource lazy namespace object ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./about/about.module": [
		"./src/app/about/about.module.ts",
		"common",
		"about-about-module"
	],
	"./contact/contact.module": [
		"./src/app/contact/contact.module.ts",
		"common",
		"contact-contact-module"
	],
	"./home/home.module": [
		"./src/app/home/home.module.ts",
		"common",
		"home-home-module"
	],
	"./list/list.module": [
		"./src/app/list/list.module.ts",
		"list-list-module"
	],
	"./post/post.module": [
		"./src/app/post/post.module.ts",
		"common",
		"post-post-module"
	],
	"./privacy-policy/privacy-policy.module": [
		"./src/app/privacy-policy/privacy-policy.module.ts",
		"common",
		"privacy-policy-privacy-policy-module"
	],
	"./terms-and-conditions/terms-and-conditions.module": [
		"./src/app/terms-and-conditions/terms-and-conditions.module.ts",
		"common",
		"terms-and-conditions-terms-and-conditions-module"
	]
};
function webpackAsyncContext(req) {
	var ids = map[req];
	if(!ids) {
		return Promise.resolve().then(function() {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(function() {
		var id = ids[0];
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = function webpackAsyncContextKeys() {
	return Object.keys(map);
};
webpackAsyncContext.id = "./src/$$_lazy_route_resource lazy recursive";
module.exports = webpackAsyncContext;

/***/ }),

/***/ "./src/app/app-routing.module.ts":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");



var routes = [
    {
        path: '',
        redirectTo: 'home',
        pathMatch: 'full'
    },
    {
        path: 'home',
        loadChildren: './home/home.module#HomePageModule'
    },
    {
        path: 'list',
        loadChildren: './list/list.module#ListPageModule'
    },
    { path: 'contact', loadChildren: './contact/contact.module#ContactPageModule' },
    { path: 'about', loadChildren: './about/about.module#AboutPageModule' },
    { path: 'privacy-policy', loadChildren: './privacy-policy/privacy-policy.module#PrivacyPolicyPageModule' },
    { path: 'terms-and-conditions', loadChildren: './terms-and-conditions/terms-and-conditions.module#TermsAndConditionsPageModule' },
    { path: ':slug', loadChildren: './post/post.module#PostPageModule' },
];
var AppRoutingModule = /** @class */ (function () {
    function AppRoutingModule() {
    }
    AppRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(routes, { preloadingStrategy: _angular_router__WEBPACK_IMPORTED_MODULE_2__["PreloadAllModules"] })
            ],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
        })
    ], AppRoutingModule);
    return AppRoutingModule;
}());



/***/ }),

/***/ "./src/app/app.component.html":
/*!************************************!*\
  !*** ./src/app/app.component.html ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-app>\r\n  <ion-split-pane>\r\n    <!---ion-menu>\r\n      <ion-header>\r\n        <ion-toolbar>\r\n          <ion-title>Menu</ion-title>\r\n        </ion-toolbar>\r\n      </ion-header>\r\n      <ion-content>\r\n        <ion-list>\r\n          <ion-menu-toggle auto-hide=\"false\" *ngFor=\"let p of appPages\">\r\n            <ion-item [routerDirection]=\"'root'\" [routerLink]=\"[p.url]\">\r\n              <ion-icon slot=\"start\" [name]=\"p.icon\"></ion-icon>\r\n              <ion-label>\r\n                {{p.title}}\r\n              </ion-label>\r\n            </ion-item>\r\n          </ion-menu-toggle>\r\n        </ion-list>\r\n      </ion-content>\r\n    </ion-menu--->\r\n    <ion-router-outlet main>\r\n\t<!-------header start--------->\r\n\t <!-------header end--------->\r\n\t</ion-router-outlet>\r\n  </ion-split-pane>\r\n</ion-app>\r\n"

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic-native/splash-screen/ngx */ "./node_modules/@ionic-native/splash-screen/ngx/index.js");
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "./node_modules/@ionic-native/status-bar/ngx/index.js");





var AppComponent = /** @class */ (function () {
    function AppComponent(platform, splashScreen, statusBar) {
        this.platform = platform;
        this.splashScreen = splashScreen;
        this.statusBar = statusBar;
        this.appPages = [
            {
                title: 'Home',
                url: '/',
                icon: 'home'
            },
            {
                title: 'List',
                url: '/list',
                icon: 'list'
            }
        ];
        this.initializeApp();
    }
    AppComponent.prototype.initializeApp = function () {
        var _this = this;
        this.platform.ready().then(function () {
            _this.statusBar.styleDefault();
            _this.splashScreen.hide();
        });
    };
    AppComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-root',
            template: __webpack_require__(/*! ./app.component.html */ "./src/app/app.component.html")
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"],
            _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_3__["SplashScreen"],
            _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_4__["StatusBar"]])
    ], AppComponent);
    return AppComponent;
}());



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic-native/splash-screen/ngx */ "./node_modules/@ionic-native/splash-screen/ngx/index.js");
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "./node_modules/@ionic-native/status-bar/ngx/index.js");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./app-routing.module */ "./src/app/app-routing.module.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var ngx_infinite_scroll__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ngx-infinite-scroll */ "./node_modules/ngx-infinite-scroll/modules/ngx-infinite-scroll.es5.js");
/* harmony import */ var _angular_service_worker__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/service-worker */ "./node_modules/@angular/service-worker/fesm5/service-worker.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _agm_core__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @agm/core */ "./node_modules/@agm/core/index.js");
/* harmony import */ var _providers_seo_seo__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../providers/seo/seo */ "./src/providers/seo/seo.ts");
/* harmony import */ var _angular_http__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/http */ "./node_modules/@angular/http/fesm5/http.js");
/* harmony import */ var ng2_bootstrap_pagination__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ng2-bootstrap/pagination */ "./node_modules/ng2-bootstrap/pagination/index.js");

















// import pagination component

var AppModule = /** @class */ (function () {
    function AppModule() {
    }
    AppModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            declarations: [_app_component__WEBPACK_IMPORTED_MODULE_7__["AppComponent"]],
            entryComponents: [],
            imports: [
                _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__["BrowserModule"],
                _angular_common_http__WEBPACK_IMPORTED_MODULE_9__["HttpClientModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"].forRoot(),
                _agm_core__WEBPACK_IMPORTED_MODULE_14__["AgmCoreModule"].forRoot(),
                _app_routing_module__WEBPACK_IMPORTED_MODULE_8__["AppRoutingModule"],
                ngx_infinite_scroll__WEBPACK_IMPORTED_MODULE_10__["InfiniteScrollModule"],
                _angular_service_worker__WEBPACK_IMPORTED_MODULE_11__["ServiceWorkerModule"].register('ngsw-worker.js', { enabled: _environments_environment__WEBPACK_IMPORTED_MODULE_12__["environment"].production }),
                ng2_bootstrap_pagination__WEBPACK_IMPORTED_MODULE_17__["PaginationModule"].forRoot(),
                _angular_http__WEBPACK_IMPORTED_MODULE_16__["HttpModule"],
            ],
            providers: [
                _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_6__["StatusBar"],
                _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_5__["SplashScreen"],
                { provide: _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouteReuseStrategy"], useClass: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicRouteStrategy"] },
                { provide: _angular_common__WEBPACK_IMPORTED_MODULE_13__["LocationStrategy"], useClass: _angular_common__WEBPACK_IMPORTED_MODULE_13__["PathLocationStrategy"] },
                _providers_seo_seo__WEBPACK_IMPORTED_MODULE_15__["HtmlheadService"],
            ],
            bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_7__["AppComponent"]]
        })
    ], AppModule);
    return AppModule;
}());



/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
var environment = {
    production: false,
    endpointURL: 'https://www.thecodepractice.com/wp-json/',
    dateFormat: 'MMM d, y'
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm5/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(function (err) { return console.log(err); });


/***/ }),

/***/ "./src/providers/seo/seo.ts":
/*!**********************************!*\
  !*** ./src/providers/seo/seo.ts ***!
  \**********************************/
/*! exports provided: HtmlheadService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HtmlheadService", function() { return HtmlheadService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");




/*
  Generated class for the SeoProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
var HtmlheadService = /** @class */ (function () {
    function HtmlheadService(http, meta, title) {
        this.http = http;
        this.meta = meta;
        this.title = title;
        console.log('Hello HtmlheadService Provider');
    }
    HtmlheadService.prototype.addMeta = function (title, keywords, description, img) {
        this.title.setTitle(title);
        // Add Twitter Card Metatags
        this.meta.updateTag({ name: 'title', content: title });
        this.meta.updateTag({ name: 'keywords', content: keywords });
        this.meta.updateTag({ name: 'description', content: description });
        this.meta.updateTag({ name: 'image', content: img });
    };
    HtmlheadService.prototype.addMetaOg = function (title, keywords, description, img) {
        this.meta.updateTag({ property: 'og:title', content: title });
        this.meta.updateTag({ property: 'og:type', content: keywords });
        this.meta.updateTag({ property: 'og:description', content: description });
        this.meta.updateTag({ property: 'og:image', content: img });
    };
    HtmlheadService.prototype.addMetaTwitter = function (title, keywords, description, img) {
        this.meta.updateTag({ name: 'twitter:title', content: title });
        this.meta.updateTag({ name: 'twitter:card', content: keywords });
        this.meta.updateTag({ name: 'twitter:description', content: description });
        this.meta.updateTag({ name: 'twitter:image', content: img });
    };
    HtmlheadService.prototype.clearHead = function () {
        // Try to remove all META-Informaiton
        this.removeDescription();
        this.removeKeywords();
        this.removeStructuredData();
        // Add standard structured data
        this.addStructuredDataWebSite();
        this.addStructuredDataOrganisation();
    };
    HtmlheadService.prototype.removeDescription = function () {
        // Try to remove META-Tags
        try {
            document.querySelector("meta[name='description']").remove();
        }
        catch (e) {
        }
    };
    HtmlheadService.prototype.addDescription = function (content) {
        // Add the new META-Tags
        var description = document.createElement('meta');
        description.name = "description";
        description.content = content;
        document.getElementsByTagName('head')[0].appendChild(description);
    };
    HtmlheadService.prototype.removeKeywords = function () {
        // Try to remove META-Tags
        try {
            document.querySelector("meta[name='keywords']").remove();
        }
        catch (e) {
        }
    };
    HtmlheadService.prototype.addKeywords = function (content) {
        var keywords = document.createElement('meta');
        keywords.name = "keywords";
        keywords.content = content;
        document.getElementsByTagName('head')[0].appendChild(keywords);
    };
    HtmlheadService.prototype.removeStructuredData = function () {
        // Remove all Structured Data
        try {
            while (document.querySelector("script[type='application/ld+json']")) {
                document.querySelector("script[type='application/ld+json']").remove();
            }
        }
        catch (e) {
        }
    };
    HtmlheadService.prototype.addStructuredDataWebSite = function () {
        var script = document.createElement('script');
        script.type = "application/ld+json";
        script.innerText = '{"@context": "http://schema.org","@type": "WebSite","name": "Weeklystyle.de","alternateName": "Weeklystyle","url": "http://www.weeklystyle.de","sameAs": ["https://twitter.com/weeklystylede","https://www.pinterest.de/weeklystylede/"]}';
        document.getElementsByTagName('head')[0].appendChild(script);
    };
    HtmlheadService.prototype.addStructuredDataOrganisation = function () {
        var script = document.createElement('script');
        script.type = "application/ld+json";
        script.innerText = '{"@context": "http://schema.org","@type": "Organization","url":"http://www.weeklystyle.de","logo":"http://weeklystyle.de/assets/img/weeklyStyle/category.png"}';
        document.getElementsByTagName('head')[0].appendChild(script);
    };
    HtmlheadService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"], _angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__["Meta"], _angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__["Title"]])
    ], HtmlheadService);
    return HtmlheadService;
}());



/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! C:\Users\Windows\Desktop\ionic\wp-with-ionic\src\main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map