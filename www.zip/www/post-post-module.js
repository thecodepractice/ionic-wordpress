(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["post-post-module"],{

/***/ "./src/app/post/post.module.ts":
/*!*************************************!*\
  !*** ./src/app/post/post.module.ts ***!
  \*************************************/
/*! exports provided: PostPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PostPageModule", function() { return PostPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _post_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./post.page */ "./src/app/post/post.page.ts");
/* harmony import */ var _safe_pipe__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./../safe.pipe */ "./src/app/safe.pipe.ts");








var routes = [
    {
        path: '',
        component: _post_page__WEBPACK_IMPORTED_MODULE_6__["PostPage"]
    }
];
var PostPageModule = /** @class */ (function () {
    function PostPageModule() {
    }
    PostPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_post_page__WEBPACK_IMPORTED_MODULE_6__["PostPage"], _safe_pipe__WEBPACK_IMPORTED_MODULE_7__["SafePipe"]]
        })
    ], PostPageModule);
    return PostPageModule;
}());



/***/ }),

/***/ "./src/app/post/post.page.html":
/*!*************************************!*\
  !*** ./src/app/post/post.page.html ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-content padding>\r\n<ion-header>\r\n  <!---ion-toolbar>\r\n    <ion-buttons slot=\"start\">\r\n      <ion-menu-button></ion-menu-button>\r\n    </ion-buttons>\r\n    <ion-title>\r\n      Home\r\n    </ion-title>\r\n  </ion-toolbar--->\r\n<header>\r\n\r\n\t\t<div class=\"top_bar\">\r\n\t\t\t<div class=\"container\">\r\n\t\t\t\t<ul>\t\t\t\t\t\r\n\t\t\t\t\t<li>\r\n\t\t\t\t\t\t<a href=\"https://www.facebook.com/\" target=\"_blank\"><i class=\"fab fa-facebook-f\"></i></a>\r\n\t\t\t\t\t\t<a href=\"https://twitter.com/\" target=\"_blank\"><i class=\"fab fa-twitter\"></i></a>\r\n\t\t\t\t\t\t<a href=\"https://www.linkedin.com/\" target=\"_blank\"><i class=\"fab fa-linkedin-in\"></i></a>\r\n\t\t\t\t\t\t\r\n\t\t\t\t\t</li>\r\n\t\t\t\t</ul>\r\n\t\t\t</div>\r\n\t\t\t</div>\r\n\t\t<div class=\"header-section\">\t\r\n\t\t\t<div class=\"container\">\r\n\t\t\t\t<div class=\"row\">\r\n\t\t\t\t\t<div class=\"logo\">\r\n\t\t\t\t\t\t<a href=\"/home\"><img src=\"../../assets/images/logo.png\"></a>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t\t<div class=\"lower_bar\">\r\n\t\t\t\t\t\t<nav class=\"navbar navbar-expand-lg navbar-light bg-light\">\r\n\t\t\t\t\t\t<button class=\"navbar-toggler\" type=\"button\" data-toggle=\"collapse\" data-target=\"#navbarSupportedContent\" aria-controls=\"navbarSupportedContent\" aria-expanded=\"false\" aria-label=\"Toggle navigation\"><span class=\"navbar-toggler-icon\"></span></button><div class=\"collapse navbar-collapse\" id=\"navbarSupportedContent\">\r\n\t\t\t\t\t\t<ul class=\"navbar-nav mr-auto\">\r\n\t\t\t\t\t\t\t<li class=\"nav-item active\"><a class=\"nav-link\" href=\"/home\">Home</a></li>\r\n\t\t\t\t\t\t\t<li class=\"nav-item active\"><a class=\"nav-link\" href=\"/about\">About Us</a></li>\r\n\t\t\t\t\t\t\t<li class=\"nav-item\"><a class=\"nav-link\" href=\"/contact\">Contact Us</a></li>\r\n\t\t\t\t\t\t</ul></div></nav>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t</div>\r\n\t\t\t</div>\r\n\t\t</div>\r\n\t\t\r\n\t</header>\r\n\t\r\n</ion-header>\r\n<div class=\"inner-post\" *ngIf=\"skeletion\">\r\n<div class=\"container\">\r\n  <ion-grid>\r\n  <ion-row>\r\n    <ion-col size=\"12\">\r\n     <ion-skeleton-text animated style=\"height: 40px;width:30%;\"></ion-skeleton-text>\r\n\t \r\n    </ion-col>\r\n    <ion-col  size=\"12\" class=\"skeleton-img\">\r\n     <ion-skeleton-text animated style=\"height: 200px;width:40%;\"></ion-skeleton-text>\r\n\t \r\n    </ion-col>\r\n  \r\n  </ion-row>\r\n   <ion-row>\r\n    <ion-col  size=\"12\">\r\n     <ion-skeleton-text animated style=\"height: 40px;\"></ion-skeleton-text>\r\n    </ion-col>\r\n\t <ion-col  size=\"12\">\r\n     <ion-skeleton-text animated style=\"height: 43px;\"></ion-skeleton-text>\r\n    </ion-col>\r\n    <ion-col   size=\"12\">\r\n     <ion-skeleton-text animated style=\"height: 43px;\"></ion-skeleton-text>\r\n\t \r\n    </ion-col>\r\n    <ion-col  size=\"12\">\r\n     <ion-skeleton-text animated style=\"height: 43px;\"></ion-skeleton-text>\r\n\t \r\n    </ion-col>\r\n\t\r\n  \r\n\r\n  </ion-row>\r\n </ion-grid>\r\n </div></div>\r\n<div class=\"inner-post\" *ngIf=\"section_web\">\r\n<div class=\"container\" *ngIf=\"item\">\r\n\r\n\r\n\t<h1 [innerHTML]=\"item.title.rendered\"></h1>\r\n\t<img src=\"{{item.fimg_url}}\" />\t\t\r\n\t<div [innerHTML]=\"item.cat_names_all\" class=\"catagory\"></div>\r\n\t<div [innerHTML]=\"item.tag_names\" class=\"tags\"></div>\r\n\t<ion-card-subtitle>{{ item.date | date:dateFormat }}</ion-card-subtitle>\r\n\t<div [innerHTML]=\"item.content.rendered  | safe: 'html'\" class=\"post-discription\" id=\"discription\"></div>\r\n\t\r\n\t</div>\r\n</div>\r\n  <div class=\"footer-section\">\r\n\t<div class=\"container\">\r\n\t\t<div class=\"row\">\r\n\t\t\t<div class=\"col-sm-4 footer1\"><figure class=\"image\"><img src=\"../../assets/images/logo.png\" alt=\"The Code Practice\"></figure>\r\n\t\t\t<p></p>\r\n\t\t\t</div>\r\n\t\t\t<div class=\"col-sm-3 footer1\">\r\n\t\t\t<h2>About Me</h2>\r\n\t\t\t<p><a href=\"/about\">I’m a writer, blogger and seriously passionate about development and looking the best while doing it!</a></p>\r\n\t\t\t</div>\r\n\t\t\t<div class=\"col-sm-3 footer1\">\r\n\t\t\t<h2>Menus</h2>\r\n\t\t\t<ul><li><a class=\"navbar-item\" href=\"/home\">Blog</a></li><li><a class=\"navbar-item\" href=\"/contact\">Contact me</a></li></ul>\r\n\t\t\t</div>\r\n\t\t\t<div class=\"col-sm-2 footer1\"><button type=\"button\" class=\"btn btn-primary\" data-toggle=\"modal\" data-target=\"#myModal\">Message Me</button></div>\r\n\t\t</div>\r\n\t</div>\r\n\t\t<div class=\"bottom-footer\">\r\n\t\t\t<div class=\"container\">\r\n\t\t\t\t<div class=\"row\">\r\n\t\t\t\t\t<div class=\"col-sm-8 left-menu\">\r\n\t\t\t\t\t<ul><li>The Code Practice © 2020</li><li><a class=\"navbar-item\" href=\"/privacy-policy\">Privacy Policy</a></li><li><a class=\"navbar-item\" href=\"/terms-and-conditions\">Terms and Conditions</a></li></ul>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t<div class=\"col-sm-4 right-menu\">\r\n\t\t\t\t\t<ul>\r\n\t\t\t\t\t<li><a href=\"https://www.facebook.com/\" target=\"_blank\"><i class=\"fab fa-facebook-f\"></i></a></li>\r\n\t\t\t\t\t<li><a href=\"https://twitter.com/\" target=\"_blank\"><i class=\"fab fa-twitter\"></i></a></li>\r\n\t\t\t\t\t<li><a href=\"https://www.linkedin.com/\" target=\"_blank\"><i class=\"fab fa-linkedin-in\"></i></a></li>\r\n\t\t\t\t\t<li><a href=\"#\"><i class=\"fas fa-wifi\"></i></a></li>\r\n\t\t\t\t\t</ul>\r\n\t\t\t\t</div>\r\n\t\t\t\t</div>\r\n\t\t\t</div>\r\n\t\t</div>\r\n</div>\r\n\r\n</ion-content>"

/***/ }),

/***/ "./src/app/post/post.page.scss":
/*!*************************************!*\
  !*** ./src/app/post/post.page.scss ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "body {\n  font-family: 'Open Sans', sans-serif; }\n\nul {\n  padding: 0; }\n\nion-content .inner-scroll {\n  padding-left: 0px !important;\n  padding-right: 0px !important;\n  -webkit-padding-start: unset !important;\n  padding-inline-start: unset !important;\n  -webkit-padding-end: unset !important;\n  padding-inline-end: unset !important; }\n\n.welcome-card ion-img {\n  max-height: 35vh;\n  overflow: hidden; }\n\n.banner-img img {\n  width: 100%; }\n\n.menu-type-overlay.menu-enabled.menu-side-start.hydrated.split-pane-side.menu-pane-visible {\n  display: none; }\n\napp-home .ion-page {\n  position: relative;\n  display: unset; }\n\n.top_bar {\n  text-align: right;\n  background-color: #036; }\n\n.top_bar ul {\n    margin: 0;\n    padding: 2px 0; }\n\n.top_bar ul li {\n    display: inline-block; }\n\n.top_bar ul li a {\n    color: #fff;\n    padding: 0 7px; }\n\n.header-section {\n  width: 100%;\n  padding: 10px 0; }\n\n.logo {\n  width: 50%; }\n\n.logo img {\n    width: 320px; }\n\n.right-menu {\n  text-align: right; }\n\n.lower_bar {\n  width: 50%; }\n\n.lower_bar nav.navbar.navbar-expand-lg.navbar-light.bg-light {\n    padding: 32px 0;\n    background-color: transparent !important; }\n\n.lower_bar nav.navbar ul {\n    text-align: right;\n    display: inline-block;\n    width: 100%; }\n\n.lower_bar nav.navbar ul li {\n      padding: 0 6px;\n      display: inline-block; }\n\n.lower_bar nav.navbar ul a {\n      text-transform: uppercase;\n      font-size: 14px;\n      color: #002231 !important;\n      font-weight: 700;\n      font-family: \"Open Sans\", sans-serif;\n      letter-spacing: .1em;\n      transition: all .3s linear 0ms;\n      position: relative; }\n\n.lower_bar nav.navbar ul li.nav-item.active a::after,\n    .lower_bar nav.navbar ul a:hover:after {\n      content: \"\";\n      position: absolute;\n      background-color: #036;\n      width: 20px;\n      height: 6px;\n      bottom: 0;\n      left: 0;\n      right: 0;\n      margin: auto; }\n\n.footer-section {\n  width: 100%;\n  background-color: #f1f1f1;\n  padding: 60px 0 0;\n  float: left;\n  font-family: 'Open Sans', sans-serif; }\n\n.footer-section .footer1 figure.image {\n    margin: 0; }\n\n.footer-section .footer1 img {\n    width: 245px !important;\n    margin-bottom: 10px; }\n\n.footer-section .footer1 p {\n    padding: 0 55px 0 0;\n    font-size: 14px;\n    color: #504f4f;\n    line-height: 26px; }\n\n.footer-section .footer1 ul li {\n    padding: 0;\n    margin: 0;\n    display: block; }\n\n.footer-section .footer1 a.navbar-item {\n    cursor: pointer;\n    font-size: 14px;\n    text-decoration: none;\n    color: #504f4f;\n    background: transparent !important;\n    padding: 0;\n    margin-bottom: 10px; }\n\n.footer-section .footer1 a.navbar-item:hover {\n    color: #6a8c30; }\n\n.footer-section .footer1 h2 {\n    font-weight: 700;\n    font-size: 22px;\n    margin: 0 0 60px 0; }\n\n.footer-section .footer1 button {\n    background: transparent;\n    border: 2px solid #036;\n    color: #036;\n    font-size: 14px;\n    line-height: 1;\n    letter-spacing: .02em;\n    margin: 0;\n    padding: 10px 38px;\n    position: relative;\n    text-transform: uppercase;\n    font-weight: 700;\n    transition: all .3s linear 0ms; }\n\n.footer-section .footer1 button:hover {\n    background: #036;\n    color: #fff; }\n\n.footer-section .bottom-footer {\n    width: 100%;\n    background-color: #dde1da;\n    padding: 20px 0;\n    margin-top: 65px; }\n\n.footer-section .bottom-footer ul {\n      margin: 0;\n      padding: 0; }\n\n.footer-section .bottom-footer ul li {\n      display: inline-block;\n      padding: 0 6px;\n      margin: 0;\n      color: #000;\n      font-size: 14px; }\n\n.footer-section .bottom-footer ul li a {\n      color: #036; }\n\n.footer-section .bottom-footer col-sm-6.right-menu {\n      text-align: right; }\n\n.footer-section .bottom-footer a.css-1dnwvu3 {\n      color: #000;\n      text-transform: uppercase;\n      font-weight: 700;\n      font-size: 14px; }\n\n.footer-section .bottom-footer .navbar-start nav.navbar.navbar-expand-lg.navbar-light.bg-light {\n      background: transparent !important;\n      padding: 0; }\n\n.footer1 a {\n  color: #504f4f;\n  text-decoration: none !important; }\n\n.footer1 a:hover {\n  color: #036; }\n\nion-col.md.hydrated {\n  float: left;\n  padding: 10px 10px; }\n\n.ion-padding.custom-skeleton.post-skeleton {\n  margin: 35px 0; }\n\n.ion-padding, [padding] {\n  --padding-start: var(--ion-padding, 0px);\n  --padding-end: var(--ion-padding, 0px);\n  --padding-top: var(--ion-padding, 0px);\n  --padding-bottom: var(--ion-padding, 0px);\n  padding-left: var(--ion-padding, 0px);\n  padding-right: var(--ion-padding, 0px);\n  padding-top: var(--ion-padding, 0px);\n  padding-bottom: var(--ion-padding, 0px); }\n\nbutton:focus {\n  outline: none; }\n\n/*inner post page*/\n\n.inner-post {\n  margin: 70px 0;\n  width: 100%;\n  float: left; }\n\n.inner-post h1 {\n    text-transform: uppercase;\n    font-size: 22px;\n    color: #000;\n    margin: 0 0 20px 0;\n    font-family: \"Open Sans\", sans-serif;\n    font-weight: bold; }\n\n.inner-post .post-discription {\n    color: #585858;\n    font-size: 16px;\n    line-height: 30px;\n    font-family: \"Open Sans\", sans-serif; }\n\n.inner-post ion-card-subtitle.md.hydrated {\n    margin: 15px 0;\n    color: #033459;\n    font-size: 18px;\n    font-weight: bold;\n    font-family: \"Open Sans\", sans-serif; }\n\n.inner-post .tags {\n    color: #033156;\n    font-size: 16px; }\n\n.catagory {\n  margin: 5px 0; }\n\n/*media query start from here*/\n\n@media (max-width: 1199px) {\n  .lower_bar nav.navbar ul a {\n    text-transform: uppercase;\n    font-size: 12px !important; }\n  ion-list.md.list-md.hydrated ion-card-title.md.hydrated {\n    min-height: 60px;\n    font-size: 14px; }\n  ion-list.md.list-md.hydrated .discription {\n    min-height: 170px; } }\n\n@media (max-width: 991px) {\n  .lower_bar nav.navbar.navbar-expand-lg.navbar-light.bg-light {\n    float: right;\n    width: 100%;\n    position: absolute;\n    left: 0;\n    right: 0; }\n  .lower_bar .navbar-collapse {\n    position: absolute;\n    top: 101px;\n    background-color: #036;\n    z-index: 999;\n    width: 100%; }\n  .lower_bar nav.navbar ul li {\n    display: block; }\n  .lower_bar nav.navbar ul li.nav-item.active a::after, .lower_bar nav.navbar ul a:hover:after {\n    left: auto;\n    right: 0; }\n  .lower_bar .navbar-toggler {\n    width: 100%;\n    border: none;\n    text-align: right; }\n  .lower_bar nav.navbar ul a {\n    color: #fff !important; }\n  .lower_bar nav.navbar ul {\n    padding: 15px 0; }\n  .lower_bar nav.navbar ul a:hover::after {\n    content: none; }\n  .footer-section .footer1 button {\n    padding: 10px 24px; }\n  .footer-section .footer1 p {\n    padding: 0 15px 0 0; } }\n\n@media (max-width: 767px) {\n  .lower_bar .navbar-collapse {\n    top: 70px; }\n  .lower_bar nav.navbar.navbar-expand-lg.navbar-light.bg-light {\n    padding: 16px 0; }\n  .logo {\n    padding: 0 10px; }\n  .logo img {\n    width: 200px; }\n  ion-list.md.list-md.hydrated ion-card-title.md.hydrated {\n    min-height: 100%; }\n  ion-list.md.list-md.hydrated .discription {\n    min-height: 100%; }\n  .inner-post .md.hydrated {\n    width: 100% !important; }\n  .inner-post .post-discription {\n    padding: 0; }\n  .inner-post {\n    margin: 40px 0; }\n  .right-menu {\n    text-align: center; }\n  .left-menu, .right-menu {\n    max-width: 100%;\n    width: 100%;\n    flex: auto;\n    text-align: center !important; } }\n\n@media (max-width: 556px) {\n  .lower_bar .navbar-collapse {\n    top: 58px; }\n  .footer-section .footer1 h2 {\n    margin: 0; } }\n\n@media (max-width: 414px) {\n  .lower_bar nav.navbar.navbar-expand-lg.navbar-light.bg-light {\n    padding: 0px 0; } }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcG9zdC9DOlxcVXNlcnNcXFdpbmRvd3NcXERlc2t0b3BcXGlvbmljXFx3cC13aXRoLWlvbmljL3NyY1xcYXBwXFxwb3N0XFxwb3N0LnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNBLG9DQUFvQyxFQUFBOztBQU1wQztFQUNJLFVBQVUsRUFBQTs7QUFFZDtFQUVJLDRCQUE0QjtFQUM1Qiw2QkFBNkI7RUFDN0IsdUNBQXVDO0VBQ3ZDLHNDQUFzQztFQUN0QyxxQ0FBcUM7RUFDckMsb0NBQW9DLEVBQUE7O0FBR3hDO0VBQ0UsZ0JBQWdCO0VBQ2hCLGdCQUFnQixFQUFBOztBQUVsQjtFQUNJLFdBQVcsRUFBQTs7QUFFZjtFQUNJLGFBQWEsRUFBQTs7QUFFakI7RUFFRSxrQkFBa0I7RUFDbEIsY0FBYyxFQUFBOztBQUloQjtFQUNBLGlCQUFpQjtFQUNiLHNCQUFzQixFQUFBOztBQUYxQjtJQUtDLFNBQVM7SUFDTixjQUFjLEVBQUE7O0FBTmxCO0lBU0kscUJBQXFCLEVBQUE7O0FBVHpCO0lBYUksV0FBVztJQUNYLGNBQWMsRUFBQTs7QUFHbEI7RUFDSSxXQUFXO0VBQ1gsZUFBZSxFQUFBOztBQUVuQjtFQUNJLFVBQVUsRUFBQTs7QUFEZDtJQUdJLFlBQVksRUFBQTs7QUFHaEI7RUFDSSxpQkFBaUIsRUFBQTs7QUFFckI7RUFDSSxVQUFVLEVBQUE7O0FBRGQ7SUFJSSxlQUFlO0lBQ2Qsd0NBQXdDLEVBQUE7O0FBTDdDO0lBUUksaUJBQWlCO0lBQ2pCLHFCQUFxQjtJQUNyQixXQUFXLEVBQUE7O0FBVmY7TUFhRyxjQUFjO01BQ2QscUJBQXFCLEVBQUE7O0FBZHhCO01BaUJFLHlCQUF5QjtNQUN6QixlQUFlO01BQ2YseUJBQXdCO01BQ3hCLGdCQUFnQjtNQUNoQixvQ0FwRitCO01BcUYvQixvQkFBb0I7TUFDcEIsOEJBQThCO01BQzlCLGtCQUFrQixFQUFBOztBQXhCcEI7O01BNkJHLFdBQVc7TUFDWCxrQkFBa0I7TUFDbEIsc0JBQXNCO01BQ3RCLFdBQVc7TUFDWCxXQUFXO01BQ1gsU0FBUztNQUNULE9BQU87TUFDUCxRQUFRO01BQ1IsWUFBWSxFQUFBOztBQU9mO0VBQ0MsV0FBVTtFQUNWLHlCQUF3QjtFQUN4QixpQkFBZ0I7RUFDaEIsV0FBVztFQUNYLG9DQUFvQyxFQUFBOztBQUxyQztJQVFHLFNBQVMsRUFBQTs7QUFSWjtJQVdFLHVCQUFxQjtJQUNyQixtQkFBa0IsRUFBQTs7QUFacEI7SUFlRSxtQkFBa0I7SUFDbEIsZUFBYztJQUNkLGNBQWE7SUFDYixpQkFFQSxFQUFBOztBQXBCRjtJQXNCRyxVQUFTO0lBQUMsU0FBUTtJQUNsQixjQUNELEVBQUE7O0FBeEJGO0lBeUJpQixlQUFjO0lBQUMsZUFBYztJQUFDLHFCQUFvQjtJQUFDLGNBQWE7SUFBQyxrQ0FBZ0M7SUFBQyxVQUFTO0lBQUMsbUJBQzNILEVBQUE7O0FBMUJGO0lBMkJzQixjQUFhLEVBQUE7O0FBM0JuQztJQTZCSyxnQkFBZTtJQUFDLGVBQWM7SUFBQyxrQkFBa0IsRUFBQTs7QUE3QnREO0lBK0JTLHVCQUFzQjtJQUFDLHNCQUFxQjtJQUFDLFdBQVU7SUFBQyxlQUFjO0lBQUMsY0FBYTtJQUFDLHFCQUFvQjtJQUFDLFNBQVE7SUFBQyxrQkFBaUI7SUFBQyxrQkFBaUI7SUFBQyx5QkFBd0I7SUFBQyxnQkFBZTtJQUF1Qyw4QkFBNkIsRUFBQTs7QUEvQjVRO0lBaUNlLGdCQUFlO0lBQUMsV0FBVSxFQUFBOztBQWpDekM7SUFxQ0UsV0FBVTtJQUFDLHlCQUF3QjtJQUFDLGVBQWM7SUFBQyxnQkFBZSxFQUFBOztBQXJDcEU7TUF1Q0ssU0FBUTtNQUFDLFVBQVMsRUFBQTs7QUF2Q3ZCO01BeUNRLHFCQUFvQjtNQUFDLGNBQWE7TUFBQyxTQUFRO01BQUMsV0FBVTtNQUFDLGVBQWMsRUFBQTs7QUF6QzdFO01BMENVLFdBQVUsRUFBQTs7QUExQ3BCO01BNENzQixpQkFBZ0IsRUFBQTs7QUE1Q3RDO01BNkNnQixXQUFVO01BQUMseUJBQXdCO01BQUMsZ0JBQWU7TUFBQyxlQUFjLEVBQUE7O0FBN0NsRjtNQThDa0Usa0NBQWdDO01BQUMsVUFBUyxFQUFBOztBQUk1RztFQUNJLGNBQWM7RUFDZCxnQ0FBZ0MsRUFBQTs7QUFHcEM7RUFDSSxXQUFXLEVBQUE7O0FBSWY7RUFDQyxXQUFXO0VBQ1Isa0JBQWtCLEVBQUE7O0FBRXRCO0VBQ0ksY0FBYyxFQUFBOztBQUdsQjtFQUNJLHdDQUFnQjtFQUNoQixzQ0FBYztFQUNkLHNDQUFjO0VBQ2QseUNBQWlCO0VBQ2pCLHFDQUFxQztFQUNyQyxzQ0FBc0M7RUFDdEMsb0NBQW9DO0VBQ3BDLHVDQUF1QyxFQUFBOztBQUUzQztFQUNDLGFBQWEsRUFBQTs7QUFFZCxrQkFBQTs7QUFDQTtFQUNDLGNBQWM7RUFDWCxXQUFXO0VBQ1gsV0FBVyxFQUFBOztBQUhmO0lBT0kseUJBQXlCO0lBQ3pCLGVBQWU7SUFDZixXQUFXO0lBQ1gsa0JBQWtCO0lBQ3JCLG9DQXhNZ0M7SUF5TWhDLGlCQUFpQixFQUFBOztBQVpsQjtJQWlCQyxjQUFjO0lBQ1gsZUFBZTtJQUNmLGlCQUFpQjtJQUNqQixvQ0FqTjZCLEVBQUE7O0FBNkxqQztJQXdCSSxjQUFjO0lBQ2QsY0FBYztJQUNkLGVBQWU7SUFDZixpQkFBaUI7SUFDakIsb0NBek42QixFQUFBOztBQTZMakM7SUFpQ0ksY0FBYztJQUNkLGVBQWUsRUFBQTs7QUFNbkI7RUFDSSxhQUFhLEVBQUE7O0FBRWpCLDhCQUFBOztBQUVBO0VBQ0E7SUFDSSx5QkFBeUI7SUFDekIsMEJBQTBCLEVBQUE7RUFFOUI7SUFDSSxnQkFBZ0I7SUFDbkIsZUFBZSxFQUFBO0VBRWhCO0lBQ0MsaUJBQWlCLEVBQUEsRUFDakI7O0FBRUQ7RUFDQTtJQUNDLFlBQVk7SUFDVCxXQUFXO0lBQ1gsa0JBQWtCO0lBQ2xCLE9BQU87SUFDUCxRQUFRLEVBQUE7RUFFWjtJQUNDLGtCQUFrQjtJQUNsQixVQUFVO0lBQ1Ysc0JBQXNCO0lBQ3RCLFlBQVk7SUFDWixXQUFXLEVBQUE7RUFFWjtJQUNJLGNBQWMsRUFBQTtFQUVsQjtJQUNJLFVBQVU7SUFDVixRQUFRLEVBQUE7RUFFWjtJQUNDLFdBQVc7SUFDWCxZQUFZO0lBQ1osaUJBQWlCLEVBQUE7RUFHbEI7SUFDQyxzQkFBc0IsRUFBQTtFQUV2QjtJQUNDLGVBQWUsRUFBQTtFQUVoQjtJQUNJLGFBQWEsRUFBQTtFQUVqQjtJQUNDLGtCQUFrQixFQUFBO0VBRW5CO0lBQ0MsbUJBQW1CLEVBQUEsRUFDbkI7O0FBR0Q7RUFDQTtJQUNDLFNBQVMsRUFBQTtFQUVWO0lBQ0MsZUFBZSxFQUFBO0VBRWhCO0lBQ0MsZUFBZSxFQUFBO0VBRWhCO0lBQ0MsWUFBWSxFQUFBO0VBR2I7SUFDQyxnQkFBZ0IsRUFBQTtFQUVqQjtJQUNDLGdCQUFnQixFQUFBO0VBRWpCO0lBQ0Msc0JBQXNCLEVBQUE7RUFFdkI7SUFDQyxVQUFVLEVBQUE7RUFFWDtJQUNJLGNBQWMsRUFBQTtFQUVsQjtJQUNDLGtCQUFrQixFQUFBO0VBRW5CO0lBQ0ksZUFBZ0I7SUFDaEIsV0FBVztJQUNYLFVBQVU7SUFDViw2QkFBNkIsRUFBQSxFQUNoQzs7QUFFRDtFQUNBO0lBQ0ksU0FBUyxFQUFBO0VBRWI7SUFDQyxTQUFTLEVBQUEsRUFDVDs7QUFFRDtFQUNBO0lBQ0MsY0FBYyxFQUFBLEVBQ2QiLCJmaWxlIjoic3JjL2FwcC9wb3N0L3Bvc3QucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiYm9keXtcclxuZm9udC1mYW1pbHk6ICdPcGVuIFNhbnMnLCBzYW5zLXNlcmlmO1xyXG59XHJcbiRwYXJhY29sb3I6Izc5Nzc3NztcclxuJGZvbnRuYW1lOidPcGVuIFNhbnMnLCBzYW5zLXNlcmlmO1xyXG5cclxuXHRcdFxyXG51bCB7XHJcbiAgICBwYWRkaW5nOiAwO1xyXG59XHJcbmlvbi1jb250ZW50e1xyXG5cdC5pbm5lci1zY3JvbGwge1xyXG4gICAgcGFkZGluZy1sZWZ0OiAwcHggIWltcG9ydGFudDtcclxuICAgIHBhZGRpbmctcmlnaHQ6IDBweCAhaW1wb3J0YW50O1xyXG4gICAgLXdlYmtpdC1wYWRkaW5nLXN0YXJ0OiB1bnNldCAhaW1wb3J0YW50O1xyXG4gICAgcGFkZGluZy1pbmxpbmUtc3RhcnQ6IHVuc2V0ICFpbXBvcnRhbnQ7XHJcbiAgICAtd2Via2l0LXBhZGRpbmctZW5kOiB1bnNldCAhaW1wb3J0YW50O1xyXG4gICAgcGFkZGluZy1pbmxpbmUtZW5kOiB1bnNldCAhaW1wb3J0YW50O1xyXG59XHJcbn0gXHJcbi53ZWxjb21lLWNhcmQgaW9uLWltZyB7XHJcbiAgbWF4LWhlaWdodDogMzV2aDtcclxuICBvdmVyZmxvdzogaGlkZGVuO1xyXG59XHJcbi5iYW5uZXItaW1nIGltZyB7XHJcbiAgICB3aWR0aDogMTAwJTtcclxufVxyXG4ubWVudS10eXBlLW92ZXJsYXkubWVudS1lbmFibGVkLm1lbnUtc2lkZS1zdGFydC5oeWRyYXRlZC5zcGxpdC1wYW5lLXNpZGUubWVudS1wYW5lLXZpc2libGUge1xyXG4gICAgZGlzcGxheTogbm9uZTtcclxufVxyXG5hcHAtaG9tZSB7XHJcblx0Lmlvbi1wYWdlIHtcclxuXHRcdHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuXHRcdGRpc3BsYXk6IHVuc2V0O1xyXG5cdH1cclxufVxyXG5cclxuLnRvcF9iYXIge1xyXG50ZXh0LWFsaWduOiByaWdodDtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICMwMzY7XHJcblx0XHJcbnVse1xyXG5cdG1hcmdpbjogMDtcclxuICAgIHBhZGRpbmc6IDJweCAwO1xyXG59XHJcbnVsIGxpIHtcclxuICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcclxufVxyXG5cclxudWwgbGkgYSB7XHJcbiAgICBjb2xvcjogI2ZmZjtcclxuICAgIHBhZGRpbmc6IDAgN3B4O1xyXG59XHJcbn1cclxuLmhlYWRlci1zZWN0aW9uIHtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgcGFkZGluZzogMTBweCAwO1xyXG59XHJcbi5sb2dvIHtcclxuICAgIHdpZHRoOiA1MCU7XHJcblx0IGltZyB7XHJcbiAgICB3aWR0aDogMzIwcHg7XHJcbn1cclxufVxyXG4ucmlnaHQtbWVudSB7XHJcbiAgICB0ZXh0LWFsaWduOiByaWdodDtcclxufVxyXG4ubG93ZXJfYmFyIHtcclxuICAgIHdpZHRoOiA1MCU7XHJcblx0XHJcblx0bmF2Lm5hdmJhci5uYXZiYXItZXhwYW5kLWxnLm5hdmJhci1saWdodC5iZy1saWdodCB7XHJcbiAgICBwYWRkaW5nOiAzMnB4IDA7XHJcblx0ICAgIGJhY2tncm91bmQtY29sb3I6IHRyYW5zcGFyZW50ICFpbXBvcnRhbnQ7XHJcblx0fVxyXG5cdG5hdi5uYXZiYXIgdWwge1xyXG4gICAgdGV4dC1hbGlnbjogcmlnaHQ7XHJcbiAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuXHRcclxuXHRcdCBsaSB7XHJcblx0XHRcdHBhZGRpbmc6IDAgNnB4O1xyXG5cdFx0XHRkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcblx0XHR9XHJcblx0XHRhIHtcclxuXHRcdHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XHJcblx0XHRmb250LXNpemU6IDE0cHg7XHJcblx0XHRjb2xvcjogIzAwMjIzMSFpbXBvcnRhbnQ7XHJcblx0XHRmb250LXdlaWdodDogNzAwO1xyXG5cdFx0Zm9udC1mYW1pbHk6ICRmb250bmFtZTtcclxuXHRcdGxldHRlci1zcGFjaW5nOiAuMWVtO1xyXG5cdFx0dHJhbnNpdGlvbjogYWxsIC4zcyBsaW5lYXIgMG1zO1xyXG5cdFx0cG9zaXRpb246IHJlbGF0aXZlO1xyXG5cdFx0XHJcblx0XHR9XHJcblx0XHRsaS5uYXYtaXRlbS5hY3RpdmUgYTo6YWZ0ZXIsXHJcblx0XHQgYTpob3ZlcjphZnRlciB7XHJcblx0XHRcdGNvbnRlbnQ6IFwiXCI7XHJcblx0XHRcdHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuXHRcdFx0YmFja2dyb3VuZC1jb2xvcjogIzAzNjtcclxuXHRcdFx0d2lkdGg6IDIwcHg7XHJcblx0XHRcdGhlaWdodDogNnB4O1xyXG5cdFx0XHRib3R0b206IDA7XHJcblx0XHRcdGxlZnQ6IDA7XHJcblx0XHRcdHJpZ2h0OiAwO1xyXG5cdFx0XHRtYXJnaW46IGF1dG87XHJcblx0XHR9XHJcblx0fVxyXG5cdFxyXG5cdFxyXG59XHJcblxyXG4uZm9vdGVyLXNlY3Rpb257XHJcblx0d2lkdGg6MTAwJTtcclxuXHRiYWNrZ3JvdW5kLWNvbG9yOiNmMWYxZjE7XHJcblx0cGFkZGluZzo2MHB4IDAgMDtcclxuXHRmbG9hdDogbGVmdDtcclxuXHRmb250LWZhbWlseTogJ09wZW4gU2FucycsIHNhbnMtc2VyaWY7XHJcblx0LmZvb3RlcjF7XHJcblx0XHRcdGZpZ3VyZS5pbWFnZSB7XHJcblx0XHRcdG1hcmdpbjogMDtcclxuXHRcdFx0fVxyXG5cdFx0aW1ne1xyXG5cdFx0d2lkdGg6MjQ1cHghaW1wb3J0YW50O1xyXG5cdFx0bWFyZ2luLWJvdHRvbToxMHB4O1xyXG5cdFx0fVxyXG5cdFx0cHtcclxuXHRcdHBhZGRpbmc6MCA1NXB4IDAgMDtcclxuXHRcdGZvbnQtc2l6ZToxNHB4O1xyXG5cdFx0Y29sb3I6IzUwNGY0ZjtcclxuXHRcdGxpbmUtaGVpZ2h0OjI2cHhcclxuXHRcdFxyXG5cdFx0fVxyXG5cdFx0dWwgbGl7XHJcblx0XHRcdHBhZGRpbmc6MDttYXJnaW46MDtcclxuXHRcdFx0ZGlzcGxheTpibG9ja1xyXG5cdFx0fVxyXG5cdFx0YS5uYXZiYXItaXRlbXsgY3Vyc29yOnBvaW50ZXI7Zm9udC1zaXplOjE0cHg7dGV4dC1kZWNvcmF0aW9uOm5vbmU7Y29sb3I6IzUwNGY0ZjtiYWNrZ3JvdW5kOnRyYW5zcGFyZW50IWltcG9ydGFudDtwYWRkaW5nOjA7bWFyZ2luLWJvdHRvbToxMHB4XHJcblx0XHR9XHJcblx0XHRhLm5hdmJhci1pdGVtOmhvdmVye2NvbG9yOiM2YThjMzB9XHJcblx0XHRcclxuXHRcdGgye2ZvbnQtd2VpZ2h0OjcwMDtmb250LXNpemU6MjJweDttYXJnaW46IDAgMCA2MHB4IDA7IH1cclxuXHRcdFxyXG5cdFx0YnV0dG9ue2JhY2tncm91bmQ6dHJhbnNwYXJlbnQ7Ym9yZGVyOjJweCBzb2xpZCAjMDM2O2NvbG9yOiMwMzY7Zm9udC1zaXplOjE0cHg7bGluZS1oZWlnaHQ6MTtsZXR0ZXItc3BhY2luZzouMDJlbTttYXJnaW46MDtwYWRkaW5nOjEwcHggMzhweDtwb3NpdGlvbjpyZWxhdGl2ZTt0ZXh0LXRyYW5zZm9ybTp1cHBlcmNhc2U7Zm9udC13ZWlnaHQ6NzAwOy13ZWJraXQtdHJhbnNpdGlvbjphbGwgLjNzIGxpbmVhciAwbXM7dHJhbnNpdGlvbjphbGwgLjNzIGxpbmVhciAwbXN9XHJcblx0XHRcclxuXHRcdGJ1dHRvbjpob3ZlcntiYWNrZ3JvdW5kOiMwMzY7Y29sb3I6I2ZmZn1cclxuXHRcdFxyXG5cdH1cclxuXHQuYm90dG9tLWZvb3RlcntcclxuXHRcdHdpZHRoOjEwMCU7YmFja2dyb3VuZC1jb2xvcjojZGRlMWRhO3BhZGRpbmc6MjBweCAwO21hcmdpbi10b3A6NjVweDtcclxuXHRcdFxyXG5cdFx0dWx7bWFyZ2luOjA7cGFkZGluZzowfVxyXG5cdFx0XHJcblx0XHR1bCBsaXtkaXNwbGF5OmlubGluZS1ibG9jaztwYWRkaW5nOjAgNnB4O21hcmdpbjowO2NvbG9yOiMwMDA7Zm9udC1zaXplOjE0cHh9XHJcblx0XHR1bCBsaSBhe2NvbG9yOiMwMzZ9XHJcblx0XHRcclxuXHRcdGNvbC1zbS02LnJpZ2h0LW1lbnV7dGV4dC1hbGlnbjpyaWdodH1cclxuXHRcdGEuY3NzLTFkbnd2dTN7Y29sb3I6IzAwMDt0ZXh0LXRyYW5zZm9ybTp1cHBlcmNhc2U7Zm9udC13ZWlnaHQ6NzAwO2ZvbnQtc2l6ZToxNHB4fVxyXG5cdFx0Lm5hdmJhci1zdGFydCBuYXYubmF2YmFyLm5hdmJhci1leHBhbmQtbGcubmF2YmFyLWxpZ2h0LmJnLWxpZ2h0e2JhY2tncm91bmQ6dHJhbnNwYXJlbnQhaW1wb3J0YW50O3BhZGRpbmc6MH1cclxuXHRcclxuXHR9XHJcbn1cclxuLmZvb3RlcjEgYSB7XHJcbiAgICBjb2xvcjogIzUwNGY0ZjtcclxuICAgIHRleHQtZGVjb3JhdGlvbjogbm9uZSAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4uZm9vdGVyMSBhOmhvdmVyIHtcclxuICAgIGNvbG9yOiAjMDM2O1xyXG59XHJcblxyXG4gXHJcbmlvbi1jb2wubWQuaHlkcmF0ZWQge1xyXG5cdGZsb2F0OiBsZWZ0O1xyXG4gICAgcGFkZGluZzogMTBweCAxMHB4O1xyXG59XHJcbi5pb24tcGFkZGluZy5jdXN0b20tc2tlbGV0b24ucG9zdC1za2VsZXRvbiB7XHJcbiAgICBtYXJnaW46IDM1cHggMDtcclxufVxyXG5cclxuLmlvbi1wYWRkaW5nLCBbcGFkZGluZ10ge1xyXG4gICAgLS1wYWRkaW5nLXN0YXJ0OiB2YXIoLS1pb24tcGFkZGluZywgMHB4KTtcclxuICAgIC0tcGFkZGluZy1lbmQ6IHZhcigtLWlvbi1wYWRkaW5nLCAwcHgpO1xyXG4gICAgLS1wYWRkaW5nLXRvcDogdmFyKC0taW9uLXBhZGRpbmcsIDBweCk7XHJcbiAgICAtLXBhZGRpbmctYm90dG9tOiB2YXIoLS1pb24tcGFkZGluZywgMHB4KTtcclxuICAgIHBhZGRpbmctbGVmdDogdmFyKC0taW9uLXBhZGRpbmcsIDBweCk7XHJcbiAgICBwYWRkaW5nLXJpZ2h0OiB2YXIoLS1pb24tcGFkZGluZywgMHB4KTtcclxuICAgIHBhZGRpbmctdG9wOiB2YXIoLS1pb24tcGFkZGluZywgMHB4KTtcclxuICAgIHBhZGRpbmctYm90dG9tOiB2YXIoLS1pb24tcGFkZGluZywgMHB4KTtcclxufVxyXG5idXR0b246Zm9jdXMge1xyXG5cdG91dGxpbmU6IG5vbmU7XHJcbn1cclxuLyppbm5lciBwb3N0IHBhZ2UqL1xyXG4uaW5uZXItcG9zdCB7XHJcblx0bWFyZ2luOiA3MHB4IDA7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGZsb2F0OiBsZWZ0O1xyXG5cdFxyXG5cdFxyXG5cdCBoMSB7XHJcbiAgICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xyXG4gICAgZm9udC1zaXplOiAyMnB4O1xyXG4gICAgY29sb3I6ICMwMDA7XHJcbiAgICBtYXJnaW46IDAgMCAyMHB4IDA7XHJcblx0Zm9udC1mYW1pbHk6ICRmb250bmFtZTtcclxuXHRmb250LXdlaWdodDogYm9sZDtcclxuXHR9XHJcblx0XHJcblx0XHJcblx0LnBvc3QtZGlzY3JpcHRpb257XHJcblx0Y29sb3I6ICM1ODU4NTg7XHJcbiAgICBmb250LXNpemU6IDE2cHg7XHJcbiAgICBsaW5lLWhlaWdodDogMzBweDtcclxuICAgIGZvbnQtZmFtaWx5OiAkZm9udG5hbWU7XHJcbiAgIFxyXG5cdH1cclxuXHRpb24tY2FyZC1zdWJ0aXRsZS5tZC5oeWRyYXRlZCB7XHJcbiAgICBtYXJnaW46IDE1cHggMDtcclxuICAgIGNvbG9yOiAjMDMzNDU5O1xyXG4gICAgZm9udC1zaXplOiAxOHB4O1xyXG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgICBmb250LWZhbWlseTogJGZvbnRuYW1lO1xyXG5cdH1cclxuXHRcclxuXHQudGFncyB7XHJcbiAgICBcclxuICAgIGNvbG9yOiAjMDMzMTU2O1xyXG4gICAgZm9udC1zaXplOiAxNnB4O1xyXG4gICAgXHJcblx0fVxyXG5cdFxyXG59XHJcblxyXG4uY2F0YWdvcnkge1xyXG4gICAgbWFyZ2luOiA1cHggMDtcclxufVxyXG4vKm1lZGlhIHF1ZXJ5IHN0YXJ0IGZyb20gaGVyZSovXHJcblxyXG5AbWVkaWEobWF4LXdpZHRoOjExOTlweCl7XHJcbi5sb3dlcl9iYXIgbmF2Lm5hdmJhciB1bCBhIHtcclxuICAgIHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XHJcbiAgICBmb250LXNpemU6IDEycHggIWltcG9ydGFudDtcclxufVxyXG5pb24tbGlzdC5tZC5saXN0LW1kLmh5ZHJhdGVkIGlvbi1jYXJkLXRpdGxlLm1kLmh5ZHJhdGVkIHtcclxuICAgIG1pbi1oZWlnaHQ6IDYwcHg7XHJcblx0Zm9udC1zaXplOiAxNHB4O1xyXG59XHJcbmlvbi1saXN0Lm1kLmxpc3QtbWQuaHlkcmF0ZWQgLmRpc2NyaXB0aW9uIHtcclxuXHRtaW4taGVpZ2h0OiAxNzBweDtcclxufVxyXG59XHJcbkBtZWRpYSAobWF4LXdpZHRoOjk5MXB4KXtcclxuLmxvd2VyX2JhciBuYXYubmF2YmFyLm5hdmJhci1leHBhbmQtbGcubmF2YmFyLWxpZ2h0LmJnLWxpZ2h0IHtcclxuXHRmbG9hdDogcmlnaHQ7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIGxlZnQ6IDA7XHJcbiAgICByaWdodDogMDtcclxufVxyXG4ubG93ZXJfYmFyIC5uYXZiYXItY29sbGFwc2Uge1xyXG5cdHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuXHR0b3A6IDEwMXB4O1xyXG5cdGJhY2tncm91bmQtY29sb3I6ICMwMzY7XHJcblx0ei1pbmRleDogOTk5O1xyXG5cdHdpZHRoOiAxMDAlO1xyXG59XHRcclxuLmxvd2VyX2JhciBuYXYubmF2YmFyIHVsIGxpIHtcclxuICAgIGRpc3BsYXk6IGJsb2NrO1xyXG59XHRcclxuLmxvd2VyX2JhciBuYXYubmF2YmFyIHVsIGxpLm5hdi1pdGVtLmFjdGl2ZSBhOjphZnRlciwgLmxvd2VyX2JhciBuYXYubmF2YmFyIHVsIGE6aG92ZXI6YWZ0ZXIge1xyXG4gICAgbGVmdDogYXV0bztcclxuICAgIHJpZ2h0OiAwO1xyXG59XHJcbi5sb3dlcl9iYXIgLm5hdmJhci10b2dnbGVyIHtcclxuXHR3aWR0aDogMTAwJTtcclxuXHRib3JkZXI6IG5vbmU7XHJcblx0dGV4dC1hbGlnbjogcmlnaHQ7XHJcbn1cclxuXHJcbi5sb3dlcl9iYXIgbmF2Lm5hdmJhciB1bCBhIHtcclxuXHRjb2xvcjogI2ZmZiAhaW1wb3J0YW50O1xyXG59XHJcbi5sb3dlcl9iYXIgbmF2Lm5hdmJhciB1bCB7XHJcblx0cGFkZGluZzogMTVweCAwO1xyXG59XHJcbi5sb3dlcl9iYXIgbmF2Lm5hdmJhciB1bCBhOmhvdmVyOjphZnRlciB7XHJcbiAgICBjb250ZW50OiBub25lO1xyXG59XHJcbi5mb290ZXItc2VjdGlvbiAuZm9vdGVyMSBidXR0b24ge1xyXG5cdHBhZGRpbmc6IDEwcHggMjRweDtcclxufVxyXG4uZm9vdGVyLXNlY3Rpb24gLmZvb3RlcjEgcCB7XHJcblx0cGFkZGluZzogMCAxNXB4IDAgMDtcclxufVxyXG59XHJcblxyXG5AbWVkaWEobWF4LXdpZHRoOjc2N3B4KXtcclxuLmxvd2VyX2JhciAubmF2YmFyLWNvbGxhcHNlIHtcclxuXHR0b3A6IDcwcHg7XHJcbn1cdFxyXG4ubG93ZXJfYmFyIG5hdi5uYXZiYXIubmF2YmFyLWV4cGFuZC1sZy5uYXZiYXItbGlnaHQuYmctbGlnaHQge1xyXG5cdHBhZGRpbmc6IDE2cHggMDtcclxufVx0XHJcbi5sb2dvIHtcclxuXHRwYWRkaW5nOiAwIDEwcHg7XHJcbn1cclxuLmxvZ28gaW1nIHtcclxuXHR3aWR0aDogMjAwcHg7XHJcbn1cdFxyXG5cclxuaW9uLWxpc3QubWQubGlzdC1tZC5oeWRyYXRlZCBpb24tY2FyZC10aXRsZS5tZC5oeWRyYXRlZCB7XHJcblx0bWluLWhlaWdodDogMTAwJTtcclxufVxyXG5pb24tbGlzdC5tZC5saXN0LW1kLmh5ZHJhdGVkIC5kaXNjcmlwdGlvbiB7XHJcblx0bWluLWhlaWdodDogMTAwJTtcclxufVxyXG4uaW5uZXItcG9zdCAubWQuaHlkcmF0ZWQge1xyXG5cdHdpZHRoOiAxMDAlICFpbXBvcnRhbnQ7XHJcbn1cclxuLmlubmVyLXBvc3QgLnBvc3QtZGlzY3JpcHRpb24ge1xyXG5cdHBhZGRpbmc6IDA7XHJcbn1cclxuLmlubmVyLXBvc3Qge1xyXG4gICAgbWFyZ2luOiA0MHB4IDA7XHJcbn1cclxuLnJpZ2h0LW1lbnUge1xyXG5cdHRleHQtYWxpZ246IGNlbnRlcjtcclxufVxyXG4ubGVmdC1tZW51LCAucmlnaHQtbWVudSB7XHJcbiAgICBtYXgtd2lkdGg6IDEwMCUgO1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBmbGV4OiBhdXRvO1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyICFpbXBvcnRhbnQ7XHJcbn1cclxufVxyXG5AbWVkaWEobWF4LXdpZHRoOjU1NnB4KXtcclxuLmxvd2VyX2JhciAubmF2YmFyLWNvbGxhcHNlIHtcclxuICAgIHRvcDogNThweDtcclxufVxyXG4uZm9vdGVyLXNlY3Rpb24gLmZvb3RlcjEgaDIge1xyXG5cdG1hcmdpbjogMDtcclxufVxyXG59XHJcbkBtZWRpYShtYXgtd2lkdGg6NDE0cHgpe1xyXG4ubG93ZXJfYmFyIG5hdi5uYXZiYXIubmF2YmFyLWV4cGFuZC1sZy5uYXZiYXItbGlnaHQuYmctbGlnaHR7XHJcblx0cGFkZGluZzogMHB4IDA7XHJcbn1cdFxyXG5cclxufVxyXG5cclxuXHJcbiJdfQ== */"

/***/ }),

/***/ "./src/app/post/post.page.ts":
/*!***********************************!*\
  !*** ./src/app/post/post.page.ts ***!
  \***********************************/
/*! exports provided: PostPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PostPage", function() { return PostPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _shared_data_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../shared/data.service */ "./src/app/shared/data.service.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _angular_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/http */ "./node_modules/@angular/http/fesm5/http.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _providers_seo_seo__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../providers/seo/seo */ "./src/providers/seo/seo.ts");








var ENDPOINT_URL = _environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].endpointURL;
var PostPage = /** @class */ (function () {
    function PostPage(route, dataService, http, sanitizer, htmlheadService) {
        this.route = route;
        this.dataService = dataService;
        this.http = http;
        this.sanitizer = sanitizer;
        this.htmlheadService = htmlheadService;
        this.dateFormat = _environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].dateFormat;
        this.skeletion = true;
        this.section_web = false;
    }
    PostPage.prototype.ngOnInit = function () {
        var _this = this;
        var itemSlug = this.route.snapshot.paramMap.get('slug');
        var slug = itemSlug;
        this.http.get(ENDPOINT_URL + 'wp/v2/posts?slug=' + slug)
            .map(function (response) { return response.json(); })
            .subscribe(function (data) {
            _this.skeletion = false;
            _this.section_web = true;
            _this.item = data[0];
            /*************sco service**************/
            console.log(data[0]);
            var title = _this.item.title.rendered;
            var description = _this.strip_html_tags(_this.item.content.rendered);
            var keywords = _this.strip_html_tags(_this.item.content.rendered);
            var img = _this.item.fimg_url;
            _this.htmlheadService.addMeta(title, description, keywords, img);
            _this.htmlheadService.addMetaOg(title, description, keywords, img);
            _this.htmlheadService.addMetaTwitter(title, description, keywords, img);
        });
    };
    PostPage.prototype.strip_html_tags = function (str) {
        if ((str === null) || (str === ''))
            return false;
        else
            str = str.toString();
        return str.replace(/<[^>]*>/g, '').substring(0, 100);
    };
    PostPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-post',
            template: __webpack_require__(/*! ./post.page.html */ "./src/app/post/post.page.html"),
            styles: [__webpack_require__(/*! ./post.page.scss */ "./src/app/post/post.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"], _shared_data_service__WEBPACK_IMPORTED_MODULE_3__["DataService"], _angular_http__WEBPACK_IMPORTED_MODULE_5__["Http"], _angular_platform_browser__WEBPACK_IMPORTED_MODULE_6__["DomSanitizer"], _providers_seo_seo__WEBPACK_IMPORTED_MODULE_7__["HtmlheadService"]])
    ], PostPage);
    return PostPage;
}());



/***/ }),

/***/ "./src/app/safe.pipe.ts":
/*!******************************!*\
  !*** ./src/app/safe.pipe.ts ***!
  \******************************/
/*! exports provided: SafePipe */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SafePipe", function() { return SafePipe; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");



var SafePipe = /** @class */ (function () {
    function SafePipe(sanitizer) {
        this.sanitizer = sanitizer;
    }
    SafePipe.prototype.transform = function (value, type) {
        switch (type) {
            case 'html': return this.sanitizer.bypassSecurityTrustHtml(value);
            case 'style': return this.sanitizer.bypassSecurityTrustStyle(value);
            case 'script': return this.sanitizer.bypassSecurityTrustScript(value);
            case 'url': return this.sanitizer.bypassSecurityTrustUrl(value);
            case 'resourceUrl': return this.sanitizer.bypassSecurityTrustResourceUrl(value);
            default: throw new Error("Invalid safe type specified: " + type);
        }
    };
    SafePipe = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Pipe"])({
            name: 'safe'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__["DomSanitizer"]])
    ], SafePipe);
    return SafePipe;
}());



/***/ })

}]);
//# sourceMappingURL=post-post-module.js.map